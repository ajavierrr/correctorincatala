import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { useScrollToTop } from '../hooks/useScrollToTop';
import { CorrectorTool } from '../components/CorrectorTool';
import { ContentSection } from '../components/ContentSection';
import { defaultSettings, type CorrectorSettings, correctText, type Correction } from '../utils/corrector';
import { 
  CheckCircle2, 
  Target, 
  Clock, 
  Shield,
  FileText,
  Settings2,
  MousePointer,
  GraduationCap,
  Briefcase,
  PenTool,
  Users
} from 'lucide-react';

export function ValenciaPage() {
  useScrollToTop();
  const [text, setText] = useState('');
  const [corrections, setCorrections] = useState<Correction[]>([]);
  const [settings, setSettings] = useState<CorrectorSettings>(defaultSettings);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  const handleCorrect = () => {
    if (!text.trim()) return;
    const newCorrections = correctText(text, 'valencia', settings);
    setCorrections(newCorrections);
  };

  const handleCopy = () => {
    if (!text.trim()) return;
    navigator.clipboard.writeText(text).catch(console.error);
  };

  const handleClear = () => {
    setText('');
    setCorrections([]);
  };

  const schema = {
    "@context": "https://schema.org",
    "@type": "WebPage",
    "name": "Corrector Valencià | Ortografia i Gramàtica en Línia",
    "description": "El millor corrector valencià en línia ✓ Ortografia i gramàtica perfectes ✓ Fàcil d'usar ✓ Resultats al moment ✓ Prova'l ara gratis!",
    "url": "https://correctorcatala.cat/corrector-valencia/",
    "isPartOf": {
      "@type": "WebSite",
      "name": "Corrector Valencià",
      "url": "https://correctorcatala.cat/corrector-valencia/"
    }
  };

  return (
    <>
      <Helmet>
        <title>Corrector Valencià | Ortografia i Gramàtica en Línia</title>
        <meta 
          name="description" 
          content="El millor corrector valencià en línia ✓ Ortografia i gramàtica perfectes ✓ Fàcil d'usar ✓ Resultats al moment ✓ Prova'l ara gratis!" 
        />
        <link rel="canonical" href="https://correctorcatala.cat/corrector-valencia" />
        <script type="application/ld+json">
          {JSON.stringify(schema)}
        </script>
      </Helmet>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Hero Section */}
        <div className="py-12 text-center">
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-gray-900 tracking-tight mb-6">
            Corrector Valencià | Ortografia i Gramàtica en Línia
          </h1>
          <p className="text-lg text-gray-600 leading-relaxed max-w-3xl mx-auto mb-4">
            <strong>Necessites escriure en valencià amb total seguretat?</strong> El nostre corrector 
            valencià és el que estaves buscant. Una eina avançada que revisa al moment l'ortografia, 
            la gramàtica i l'estil dels teus textos.
          </p>
          <p className="text-lg text-gray-600 leading-relaxed max-w-3xl mx-auto">
            No importa si ets estudiant o professional: ara pots tenir tots els teus escrits en valencià 
            perfectes i sense errors.
          </p>
        </div>

        {/* Corrector Tool */}
        <section className="py-12">
          <CorrectorTool
            text={text}
            dialect="valencia"
            corrections={corrections}
            onTextChange={setText}
            onDialectChange={() => {}}
            onCorrect={handleCorrect}
            onCopy={handleCopy}
            onClear={handleClear}
            onOpenSettings={() => setIsSettingsOpen(true)}
          />
        </section>

        {/* Main Features */}
        <div className="py-12">
          <div className="grid md:grid-cols-2 gap-8">
            {[
              {
                icon: <CheckCircle2 className="h-6 w-6 text-red-500" />,
                title: "Corregir errors ortogràfics i gramaticals",
                description: "Detectem i corregim errors de manera instantània"
              },
              {
                icon: <Target className="h-6 w-6 text-red-500" />,
                title: "Verificar la unitat",
                description: "Assegurem que els teus textos siguen clars i correctes"
              },
              {
                icon: <Clock className="h-6 w-6 text-red-500" />,
                title: "Millora instantània",
                description: "Resultats immediats sense esperes"
              },
              {
                icon: <Shield className="h-6 w-6 text-red-500" />,
                title: "Assegurar la correcció lingüística",
                description: "Garantim la qualitat en tot moment"
              }
            ].map((feature, index) => (
              <div key={index} className="flex items-start space-x-4">
                <div className="flex-shrink-0 bg-red-50 p-3 rounded-lg">
                  {feature.icon}
                </div>
                <div>
                  <h3 className="font-medium text-gray-900">{feature.title}</h3>
                  <p className="text-sm text-gray-500">{feature.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Content Sections */}
        <ContentSection id="per-que" title="Per Què Necessites un Corrector Valencià?">
          <p>El valencià té les seues pròpies normes d'ortografia i gramàtica, i és normal tenir dubtes, especialment quan escrivim amb pressa o en l'àmbit professional. El nostre corrector valencià en línia és la solució perfecta per a:</p>
          <ul>
            <li><strong>Dir adéu als errors:</strong> Oblida't de faltes d'ortografia i gramàtica.</li>
            <li><strong>Estalviar temps:</strong> Sense revisar textos manualment.</li>
            <li><strong>Textos professionals:</strong> Amb un estil clar i elegant.</li>
          </ul>
          <p>I no només troba errors: et dóna <strong>suggeriments intel·ligents</strong> per millorar els teus escrits.</p>
        </ContentSection>

        <ContentSection id="que-es" title="Què És i Com T'Ajuda el Corrector Valencià?">
          <p>El nostre corrector valencià en línia és com tenir un expert lingüístic sempre al teu costat. Què fa per tu?</p>
          <ul>
            <li><strong>Troba i corregeix errors a l'instant:</strong> ortografia, gramàtica i estil.</li>
            <li><strong>Respecta les Normes de Castelló</strong> i les particularitats del valencià.</li>
            <li><strong>Et dóna suggeriments intel·ligents</strong> per a millorar els teus textos.</li>
          </ul>
          <p>Ara pots escriure en valencià amb total confiança, sabent que els teus textos seran sempre correctes i professionals.</p>
        </ContentSection>

        <ContentSection id="caracteristiques" title="Característiques d'un Bon Corrector Valencià">
          <p>El nostre corrector valencià en línia té tot el que necessites per escriure sense preocupacions:</p>
          <h3>Les 5 Claus del Nostre Corrector:</h3>
          <ol>
            <li><strong>Ortografia Impecable:</strong> Revisa i corregeix segons les normes del valencià.</li>
            <li><strong>Gramàtica Intel·ligent:</strong> Conjugacions, gènere i concordança sempre perfectes.</li>
            <li><strong>Millores d'Estil:</strong> Suggeriments per a textos més clars i coherents.</li>
            <li><strong>100% Valencià:</strong> Adaptat a les nostres particularitats lingüístiques.</li>
            <li><strong>Sempre a Mà:</strong> Al mòbil, ordinador o tauleta - sense instal·lar res.</li>
          </ol>
        </ContentSection>

        <ContentSection id="millor-opcio" title="El Millor Corrector Valencià en Línia">
          <p><strong>Per què triar el nostre corrector valencià?</strong> Molt senzill:</p>
          <h3>T'Oferim:</h3>
          <ul>
            <li><strong>Correcció al Moment:</strong> Troba i corregeix errors mentre escrius.</li>
            <li><strong>Fàcil d'Usar:</strong> Copia, apega i llest - així de simple.</li>
            <li><strong>Màxima Qualitat:</strong> Seguim les normes oficials del valencià.</li>
          </ul>
          <p>És l'eina perfecta per a escriure en valencià amb confiança i estil.</p>
        </ContentSection>

        <ContentSection id="avantatges" title="Avantatges del Corrector Valencià">
          <p>Per què necessites un corrector valencià en línia? Mira tots els beneficis:</p>
          <h3>T'Ajuda a:</h3>
          <ul>
            <li><strong>Estalviar Temps:</strong> Textos llargs corregits en segons.</li>
            <li><strong>Aprendre Més:</strong> Millora el teu valencià amb cada correcció.</li>
            <li><strong>Tindre'l Sempre a Mà:</strong> Al mòbil, a casa o a la feina.</li>
          </ul>
          <p>Tu centres-te en el que vols dir, que nosaltres ens encarreguem de la resta.</p>
        </ContentSection>

        <ContentSection id="tria" title="Tria el Millor Corrector Valencià">
          <p><strong>Com saber quin corrector valencià necessites?</strong> El nostre s'adapta a tots:</p>
          <h3>Perfecte Per a Tu Si Eres:</h3>
          <ul>
            <li><strong>Estudiant:</strong> Treballs perfectes i millors notes.</li>
            <li><strong>Professional:</strong> Informes i correus sense cap error.</li>
            <li><strong>Particular:</strong> Missatges i posts amb gramàtica perfecta.</li>
          </ul>
          <p>No importa què necessites escriure en valencià - tens l'eina adequada per a fer-ho bé.</p>
        </ContentSection>

        <ContentSection id="on-usar" title="On Pots Fer Servir el Corrector Valencià?">
          <p>El nostre corrector valencià t'ajuda en qualsevol situació:</p>
          <h3>Perfecte Per a:</h3>
          <ul>
            <li><strong>Estudis:</strong> Treballs i projectes sense faltes.</li>
            <li><strong>Faena:</strong> Informes i correus professionals.</li>
            <li><strong>Xarxes Socials:</strong> Posts en valencià perfectes.</li>
            <li><strong>Missatges:</strong> Comunicacions clares i correctes.</li>
          </ul>
          <p>Siga on siga que necessites escriure en valencià, tens el corrector al teu costat.</p>
        </ContentSection>

        <ContentSection id="millora" title="Millora el Teu Valencià amb el Millor Corrector">
          <p><strong>Vols destacar amb els teus textos?</strong> El nostre corrector valencià en línia és la teua millor opció. Fàcil d'usar, ràpid i precís - tot el que necessites per a escriure sense errors i amb estil.</p>
          <p><strong>Comença ara!</strong> Descobreix com de fàcil és escriure en valencià perfecte amb el nostre corrector.</p>
        </ContentSection>
      </main>
    </>
  );
}