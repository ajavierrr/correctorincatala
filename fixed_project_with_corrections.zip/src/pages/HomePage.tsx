import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { Hero } from '../components/Hero';
import { CorrectorTool } from '../components/CorrectorTool';
import { SettingsModal } from '../components/SettingsModal';
import { FeatureHighlights } from '../components/FeatureHighlights';
import { ContentSection } from '../components/ContentSection';
import { defaultSettings, type CorrectorSettings, correctText, type Correction } from '../utils/corrector';

export function HomePage() {
  const [text, setText] = useState('');
  const [dialect, setDialect] = useState('central');
  const [corrections, setCorrections] = useState<Correction[]>([]);
  const [settings, setSettings] = useState<CorrectorSettings>(defaultSettings);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  const handleCorrect = () => {
    if (!text.trim()) return;
    const newCorrections = correctText(text, dialect, settings);
    setCorrections(newCorrections);
  };

  const handleCopy = () => {
    if (!text.trim()) return;
    navigator.clipboard.writeText(text).catch(console.error);
  };

  const handleClear = () => {
    setText('');
    setCorrections([]);
  };

  const schema = {
    "@context": "https://schema.org",
    "@type": "WebPage",
    "name": "Corrector de Català Ortografia i Gramàtica en Línia",
    "description": "Escriu en català sense dubtes ✓ Ortografia i gramàtica impecables ✓ Correcció instantània ✓ Tots els dialectes ✓ Fàcil d'usar ✓ Prova'l gratis ara!",
    "url": "https://correctorcatala.cat",
    "isPartOf": {
      "@type": "WebSite",
      "name": "Corrector Català",
      "url": "https://correctorcatala.cat"
    }
  };

  return (
    <>
      <Helmet>
        <title>Corrector de Català | Ortografia i Gramàtica en Línia</title>
        <meta 
          name="description" 
          content="Escriu en català sense dubtes ✓ Ortografia i gramàtica impecables ✓ Correcció instantània ✓ Tots els dialectes ✓ Fàcil d'usar ✓ Prova'l gratis ara!" 
        />
        <link rel="canonical" href="https://correctorcatala.cat" />
        <script type="application/ld+json">
          {JSON.stringify(schema)}
        </script>
      </Helmet>

      <Hero />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Corrector Section */}
        <section className="py-12">
          <CorrectorTool
            text={text}
            dialect={dialect}
            corrections={corrections}
            onTextChange={setText}
            onDialectChange={setDialect}
            onCorrect={handleCorrect}
            onCopy={handleCopy}
            onClear={handleClear}
            onOpenSettings={() => setIsSettingsOpen(true)}
          />

          <FeatureHighlights />

          <SettingsModal
            isOpen={isSettingsOpen}
            onClose={() => setIsSettingsOpen(false)}
            settings={settings}
            onSettingsChange={setSettings}
          />
        </section>

        {/* Main Content Sections */}
        <ContentSection id="per-que" title="Per Què Necessites un Corrector en Català?">
          <p>
            El català és una llengua plena de matisos i normes gramaticals complexes. És normal tenir <strong>dubtes ortogràfics o gramaticals</strong>, especialment quan escrius amb pressa o en situacions professionals importants. Un <strong>corrector català en línia</strong> com el nostre no només detecta <strong>errors</strong> al moment, sinó que també et garanteix una <strong>escriptura sense faltes</strong>, clara i professional.
          </p>
          <p>Amb el nostre corrector català pots:</p>
          <ul>
            <li><strong>Revisar textos llargs en segons:</strong> Sense esperes, sense complicacions.</li>
            <li><strong>Evitar errors comuns i millorar la qualitat dels teus textos:</strong> Gràcies a la revisió ortogràfica i millores d'estil.</li>
            <li><strong>Treballar des de qualsevol dispositiu:</strong> Ordinador, mòbil o tauleta. Sempre disponible per ajudar-te.</li>
          </ul>
          <p>Amb aquesta eina, no hauràs de preocupar-te mai més per les errades gramaticals o ortogràfiques. Escriu amb confiança!</p>
        </ContentSection>

        <ContentSection id="que-es" title="Què és un Corrector Català i Com Pot Ajudar-te?">
          <p>
            Un <strong>corrector català</strong> és com tenir un expert lingüístic sempre al teu costat. El nostre corrector detecta i corregeix <strong>errades ortogràfiques, gramaticals i estilístiques</strong> a l'instant, assegurant que cada paraula compleixi les normes de la llengua catalana. Però no només això, també t'ofereix <strong>suggeriments d'estil</strong> que optimitzen el to i la fluïdesa del teu text.
          </p>
          <p>Tot el Que Et Proporciona:</p>
          <ul>
            <li><strong>Correcció Instantània:</strong> Errors detectats al moment, sense esperes.</li>
            <li><strong>Gramàtica Impecable:</strong> Gènere, nombre i conjugacions sempre correctes.</li>
            <li><strong>Millora d'Estil:</strong> Per a textos que flueixin de forma natural i professional.</li>
            <li><strong>Adaptació Dialectal:</strong> Català central, valencià i balear. Escriu segons les teves preferències lingüístiques.</li>
          </ul>
          <p>Amb el nostre corrector, pots confiar que cada text, des del més senzill fins al més complex, estarà lliure d'errors.</p>
        </ContentSection>

        <ContentSection id="caracteristiques" title="Característiques Principals que Ha de Tenir un Corrector Català">
          <p>
            El nostre Corrector Català en Línia té tot el que necessites per escriure amb confiança i sense errades. Aquestes són les seves característiques principals:
          </p>
          <ol>
            <li><strong>Ortografia Impecable:</strong> Corregeix faltes al moment amb total precisió.</li>
            <li><strong>Revisió Gramatical Avançada:</strong> Soluciona errors de conjugació, concordança i estructures complexes.</li>
            <li><strong>Millores d'Estil Intel·ligents:</strong> Suggeriments per optimitzar la qualitat i la claredat dels teus textos.</li>
            <li><strong>Sempre Accessible:</strong> Funciona al teu mòbil, ordinador o tauleta sense necessitat de descàrregues.</li>
            <li><strong>Adaptat als Dialectes Catalans:</strong> Central, valencià o balear, amb total compatibilitat lingüística.</li>
          </ol>
          <p>Amb aquestes funcionalitats, el nostre corrector català no té rival.</p>
        </ContentSection>

        <ContentSection id="millor-opcio" title="La Millor Opció de Correctors Catalans en Línia">
          <p>
            Si busques el millor corrector per a textos en català, aquesta és la solució ideal. Hem creat una eina dissenyada per oferir <strong>rapidesa, qualitat i senzillesa</strong>.
          </p>
          <p>Per què triar el nostre corrector català?</p>
          <ul>
            <li><strong>Correcció al moment:</strong> Les faltes desapareixen mentre escrius.</li>
            <li><strong>Interfície senzilla:</strong> Copia, enganxa i corregeix en un sol clic.</li>
            <li><strong>Qualitat garantida:</strong> Compleix les normes oficials del català més acurat.</li>
          </ul>
          <p>És l'opció perfecta per a tothom que vulgui escriure sense errors i amb estil.</p>
        </ContentSection>

        <ContentSection id="avantatges" title="Els Avantatges del Nostre Corrector">
          <p>
            Deixa enrere les revisions manuals i estalvia temps amb el nostre <strong>corrector català en línia</strong>. Aquesta eina fa tot el treball pesat per tu, mentre tu et concentres en el que realment importa: el contingut.
          </p>
          <p>Per què t'encantarà?</p>
          <ul>
            <li><strong>Estalvia Temps:</strong> Revisa textos llargs en qüestió de segons.</li>
            <li><strong>Aprèn Mentre Escrius:</strong> Cada suggeriment és una lliçó per evitar futurs errors.</li>
            <li><strong>Sempre Disponible:</strong> Treballa al mòbil, tauleta o ordinador sense interrupcions.</li>
          </ul>
          <p>Amb el nostre corrector, la teva escriptura en català sempre estarà a l'altura.</p>
        </ContentSection>

        <ContentSection id="casos-us" title="Casos d'Ús dels Correctors en Català">
          <p>
            Aquesta eina és perfecta per a qualsevol situació. Alguns exemples d'on pots utilitzar el nostre corrector català:
          </p>
          <ul>
            <li><strong>A l'escola o la universitat:</strong> Lliura treballs impecables i sense errades.</li>
            <li><strong>A la feina:</strong> Corregeix informes i correus professionals amb qualitat garantida.</li>
            <li><strong>A les xarxes socials:</strong> Publica posts i missatges sense errors.</li>
            <li><strong>Als correus personals:</strong> Impressiona amb textos clars i professionals.</li>
          </ul>
        </ContentSection>

        <ContentSection id="millora" title="Millora la Teva Escriptura en Català amb un Corrector en Línia">
          <p>
            Si vols destacar amb la teva <strong>escriptura en català</strong>, el nostre corrector és la millor opció. És una eina potent però senzilla que assegura textos sense errors i amb un estil perfecte.
          </p>
          <p className="text-xl font-semibold text-red-600">
            Comença ara mateix! Escriure en català mai ha estat tan fàcil. Amb el nostre corrector, tindràs la confiança de saber que cada paraula i cada frase estan a l'altura de les teves expectatives.
          </p>
        </ContentSection>
      </main>
    </>
  );
}