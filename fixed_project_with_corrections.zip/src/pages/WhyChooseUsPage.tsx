import React from 'react';
import { Helmet } from 'react-helmet-async';
import { useScrollToTop } from '../hooks/useScrollToTop';
import { 
  Zap, 
  Globe, 
  Sparkles, 
  Smartphone, 
  Users,
  ArrowRight,
  CheckCircle2
} from 'lucide-react';

export function WhyChooseUsPage() {
  useScrollToTop();

  const features = [
    {
      icon: <Zap className="h-8 w-8 text-red-600" />,
      title: "Correcció Instantània i Precisa",
      description: "Detectem i corregim errors ortogràfics, gramaticals i estilístics al moment, sense esperes. La nostra tecnologia avançada et permet veure els errors mentre escrius i aplicar les correccions de forma senzilla i ràpida."
    },
    {
      icon: <Globe className="h-8 w-8 text-red-600" />,
      title: "Compatible amb Tots els Dialectes",
      description: "Tant si escrius en català central, valencià o balear, el nostre corrector s'adapta perfectament a les teves necessitats lingüístiques. A més, segueix les normes oficials de la llengua per garantir una correcció precisa i fiable."
    },
    {
      icon: <Sparkles className="h-8 w-8 text-red-600" />,
      title: "Millores d'Estil Intel·ligents",
      description: "No només corregim errors; també t'ajudem a millorar l'estil i la claredat dels teus textos. Suggerim alternatives més naturals i professionals per elevar la qualitat del teu contingut."
    },
    {
      icon: <Smartphone className="h-8 w-8 text-red-600" />,
      title: "Ús Multidispositiu",
      description: "Funciona perfectament a qualsevol dispositiu: ordinador, mòbil o tauleta. Escriu des de qualsevol lloc i revisa els teus textos sense interrupcions."
    },
    {
      icon: <Users className="h-8 w-8 text-red-600" />,
      title: "Ideal per a Tots els Usuaris",
      description: "Estudiants, professionals, escriptors o usuaris particulars: tothom pot beneficiar-se del nostre corrector."
    }
  ];

  return (
    <>
      <Helmet>
        <title>Per Què Triar-nos | CorrectorCatala</title>
        <meta 
          name="description" 
          content="El teu corrector català de confiança ✓ Ràpid i precís ✓ Ortografia i gramàtica perfectes ✓ Resultats al moment ✓ Prova'l ara gratis!" 
        />
      </Helmet>

      <main className="max-w-7xl mx-auto px-4 py-12 sm:px-6 lg:px-8">
        {/* Hero Section */}
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-gray-900 mb-6">
            Per Què Triar el Nostre Corrector Català?
          </h1>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            <strong>El nostre corrector català en línia no és només una eina de revisió; és una solució completa per garantir que els teus textos en català siguin impecables.</strong> Aquí tens les raons per les quals som la millor opció:
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 gap-8 mb-16">
          {features.map((feature, index) => (
            <div 
              key={index} 
              className="bg-white p-8 rounded-xl shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="flex items-center space-x-4 mb-4">
                <div className="bg-red-50 p-3 rounded-lg">
                  {feature.icon}
                </div>
                <h2 className="text-xl font-semibold text-gray-900">
                  {feature.title}
                </h2>
              </div>
              <p className="text-gray-600 leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>

        {/* CTA Banner */}
        <div className="bg-gradient-to-r from-red-600 to-red-500 text-white rounded-2xl p-8 md:p-12 text-center">
          <h2 className="text-2xl md:text-3xl font-bold mb-4">
            Prova'l ara mateix i descobreix per què som la millor eina per escriure en català!
          </h2>
          <div className="flex justify-center mt-8">
            <a 
              href="/#"
              className="inline-flex items-center space-x-2 bg-white text-red-600 px-6 py-3 rounded-lg hover:bg-red-50 transition-colors"
            >
              <span>Començar ara</span>
              <ArrowRight className="h-5 w-5" />
            </a>
          </div>
        </div>
      </main>
    </>
  );
}