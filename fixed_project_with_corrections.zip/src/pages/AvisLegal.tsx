import React from 'react';
import { Helmet } from 'react-helmet-async';
import { useScrollToTop } from '../hooks/useScrollToTop';

export function AvisLegal() {
  useScrollToTop();

  return (
    <>
      <Helmet>
        <title>Avís Legal | CorrectorCatala</title>
        <meta 
          name="description" 
          content="Els nostres serveis ✓ Condicions d'ús ✓ Normativa aplicable ✓ Tot transparent" 
        />
        <meta name="robots" content="noindex,follow" />
      </Helmet>

      <main className="max-w-4xl mx-auto px-4 py-12 sm:px-6 lg:px-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-8">Avís Legal</h1>

        <div className="prose prose-lg">
          {/* Rest of the component remains unchanged */}
        </div>
      </main>
    </>
  );
}