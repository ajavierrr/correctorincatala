import React from 'react';
import { Helmet } from 'react-helmet-async';
import { useScrollToTop } from '../hooks/useScrollToTop';
import { 
  CreditCard, 
  Smartphone, 
  CheckCircle2, 
  Globe2, 
  UserPlus,
  Mail, 
  ArrowRight 
} from 'lucide-react';

export function FAQPage() {
  useScrollToTop();

  const questions = [
    {
      icon: <CreditCard className="h-8 w-8 text-red-600" />,
      question: 'És gratuït?',
      answer: 'Sí, la versió bàsica del nostre corrector és totalment gratuïta i accessible per a tothom.'
    },
    {
      icon: <Smartphone className="h-8 w-8 text-red-600" />,
      question: 'Funciona en tots els dispositius?',
      answer: 'Per descomptat! Pots utilitzar-lo al mòbil, ordinador o tauleta sense cap problema.'
    },
    {
      icon: <CheckCircle2 className="h-8 w-8 text-red-600" />,
      question: 'Quin tipus d\'errors detecta?',
      answer: 'El nostre corrector revisa errors ortogràfics, gramaticals i estilístics, a més de suggerir millores d\'estil.'
    },
    {
      icon: <Globe2 className="h-8 w-8 text-red-600" />,
      question: 'És compatible amb altres idiomes?',
      answer: 'Actualment, està dissenyat exclusivament per al català, amb adaptació a dialectes com central, valencià i balear.'
    },
    {
      icon: <UserPlus className="h-8 w-8 text-red-600" />,
      question: 'Necessito registrar-me?',
      answer: 'No, pots començar a utilitzar-lo immediatament sense necessitat de registre.'
    }
  ];

  return (
    <>
      <Helmet>
        <title>Dubtes Freqüents | CorrectorCatala</title>
        <meta 
          name="description" 
          content="Resol tots els teus dubtes sobre el corrector català ✓ És gratuït ✓ Compatible amb tots els dispositius ✓ Suport en català ✓ Pregunta'ns!" 
        />
      </Helmet>

      <main className="max-w-4xl mx-auto px-4 py-12 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-6">
            Preguntes Freqüents sobre el Corrector Català
          </h1>
          <p className="text-lg text-gray-600">
            Troba respostes a les preguntes més comunes sobre el nostre corrector.
          </p>
        </div>

        <div className="space-y-6">
          {questions.map((item, index) => (
            <div 
              key={index}
              className="bg-white p-6 rounded-xl shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="flex items-start space-x-4">
                <div className="bg-red-50 p-3 rounded-lg flex-shrink-0">
                  {item.icon}
                </div>
                <div>
                  <h2 className="text-xl font-semibold text-gray-900 mb-2">
                    {item.question}
                  </h2>
                  <p className="text-gray-600">
                    {item.answer}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* CTA Banner */}
        <div className="mt-12 bg-gradient-to-r from-red-600 to-red-500 text-white rounded-xl p-8 text-center">
          <h2 className="text-2xl font-bold mb-4">Tens més dubtes?</h2>
          <p className="mb-6">Contacta amb nosaltres i t'ajudarem!</p>
          <a 
            href="/#"
            className="inline-flex items-center space-x-2 bg-white text-red-600 px-6 py-3 rounded-lg hover:bg-red-50 transition-colors"
          >
            <Mail className="h-5 w-5" />
            <span>Contacta'ns</span>
            <ArrowRight className="h-5 w-5" />
          </a>
        </div>
      </main>
    </>
  );
}