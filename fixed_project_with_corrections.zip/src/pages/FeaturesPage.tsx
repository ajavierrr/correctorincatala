import React from 'react';
import { Helmet } from 'react-helmet-async';
import { useScrollToTop } from '../hooks/useScrollToTop';
import { 
  CheckCircle2, 
  BookOpen, 
  Sparkles, 
  Globe, 
  Smartphone,
  ArrowRight
} from 'lucide-react';

export function FeaturesPage() {
  useScrollToTop();

  const features = [
    {
      icon: <CheckCircle2 className="h-8 w-8 text-red-600" />,
      title: "Ortografia Impecable",
      description: "Corregeix totes les faltes d'ortografia al moment. Cada paraula és revisada segons les normes oficials del català per assegurar que el teu text sigui perfecte."
    },
    {
      icon: <BookOpen className="h-8 w-8 text-red-600" />,
      title: "Revisió Gramatical Avançada",
      description: "Detecta i soluciona errors gramaticals complexos, com concordances de gènere, nombre i conjugacions verbals."
    },
    {
      icon: <Sparkles className="h-8 w-8 text-red-600" />,
      title: "Suggeriments d'Estil",
      description: "Amb les nostres millores d'estil intel·ligents, els teus textos seran més clars, fluids i professionals. Perfecte per a missatges, informes i treballs acadèmics."
    },
    {
      icon: <Globe className="h-8 w-8 text-red-600" />,
      title: "Compatible amb Dialectes",
      description: "Central, valencià o balear: adapta't al dialecte que necessitis. Aquesta característica fa que el nostre corrector sigui ideal per a qualsevol usuari de parla catalana."
    },
    {
      icon: <Smartphone className="h-8 w-8 text-red-600" />,
      title: "Accessible des de Qualsevol Lloc",
      description: "No necessites instal·lacions complicades. Funciona al mòbil, tauleta o ordinador, i està sempre disponible per ajudar-te."
    }
  ];

  return (
    <>
      <Helmet>
        <title>Funcions i Eines | CorrectorCatala</title>
        <meta 
          name="description" 
          content="Descobreix tot el que pot fer el corrector català més complet ✓ Ortografia impecable ✓ Gramàtica avançada ✓ Millores d'estil ✓ Prova-ho!" 
        />
      </Helmet>

      <main className="max-w-7xl mx-auto px-4 py-12 sm:px-6 lg:px-8">
        {/* Hero Section */}
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-gray-900 mb-6">
            Característiques del Nostre Corrector Català
          </h1>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            <strong>Descobreix tot el que fa únic el nostre corrector català en línia.</strong> Aquesta eina està dissenyada per oferir la millor experiència d'ús i resultats impecables.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 gap-8 mb-16">
          {features.map((feature, index) => (
            <div 
              key={index} 
              className="bg-white p-8 rounded-xl shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="flex items-center space-x-4 mb-4">
                <div className="bg-red-50 p-3 rounded-lg">
                  {feature.icon}
                </div>
                <h2 className="text-xl font-semibold text-gray-900">
                  {feature.title}
                </h2>
              </div>
              <p className="text-gray-600 leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>

        {/* CTA Banner */}
        <div className="bg-gradient-to-r from-red-600 to-red-500 text-white rounded-2xl p-8 md:p-12 text-center">
          <h2 className="text-2xl md:text-3xl font-bold mb-4">
            Amb aquestes característiques, cap altre corrector pot competir amb nosaltres.
          </h2>
          <p className="text-xl mb-8">
            Escriu sense dubtes i amb confiança!
          </p>
          <div className="flex justify-center">
            <a 
              href="/#"
              className="inline-flex items-center space-x-2 bg-white text-red-600 px-6 py-3 rounded-lg hover:bg-red-50 transition-colors"
            >
              <span>Prova-ho ara</span>
              <ArrowRight className="h-5 w-5" />
            </a>
          </div>
        </div>
      </main>
    </>
  );
}