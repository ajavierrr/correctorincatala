import React from 'react';
import { Helmet } from 'react-helmet-async';
import { useScrollToTop } from '../hooks/useScrollToTop';
import { Shield, Lock, Database, Mail, UserCheck, Settings } from 'lucide-react';

export function PoliticaPrivacitat() {
  useScrollToTop();

  return (
    <>
      <Helmet>
        <title>Privacitat | CorrectorCatala</title>
        <meta 
          name="description" 
          content="La teva privacitat és important ✓ Descobreix com protegim les teves dades ✓ RGPD garantit ✓ Màxima seguretat ✓ Transparència total" 
        />
        <meta name="robots" content="noindex,follow" />
      </Helmet>

      <main className="max-w-4xl mx-auto px-4 py-12 sm:px-6 lg:px-8">
        {/* Rest of the component remains unchanged */}
      </main>
    </>
  );
}