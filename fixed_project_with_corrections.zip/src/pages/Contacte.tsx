import React from 'react';
import { Helmet } from 'react-helmet-async';
import { ContactForm } from '../components/ContactForm';
import { useScrollToTop } from '../hooks/useScrollToTop';

export function Contacte() {
  useScrollToTop();

  return (
    <>
      <Helmet>
        <title>Contacta'ns | CorrectorCatala</title>
        <meta 
          name="description" 
          content="Parla amb nosaltres ✓ Respostes ràpides ✓ Atenció personalitzada ✓ Suport en català ✓ Resolem els teus dubtes al moment ✓ T'escoltem" 
        />
      </Helmet>

      <main className="max-w-4xl mx-auto px-4 py-12 sm:px-6 lg:px-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-8">Contacte</h1>

        <div className="bg-white rounded-xl shadow-lg p-6 md:p-8">
          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <h2 className="text-xl font-semibold mb-4">Informació de contacte</h2>
              <div className="space-y-4 text-gray-600">
                <p>
                  Si tens qualsevol dubte o suggeriment, no dubtis en contactar-nos. 
                  Respondrem el més aviat possible.
                </p>
                <p>
                  <strong>Correu electrònic:</strong><br />
                  info@correctorcatala.cat
                </p>
                <p>
                  <strong>Horari d'atenció:</strong><br />
                  Dilluns a divendres<br />
                  9:00 - 18:00
                </p>
              </div>
            </div>

            <ContactForm />
          </div>
        </div>
      </main>
    </>
  );
}