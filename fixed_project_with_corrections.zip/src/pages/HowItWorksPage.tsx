import React from 'react';
import { Helmet } from 'react-helmet-async';
import { useScrollToTop } from '../hooks/useScrollToTop';
import { 
  FileText, 
  Globe, 
  MousePointer, 
  CheckCircle2,
  ArrowRight,
  Zap
} from 'lucide-react';

export function HowItWorksPage() {
  useScrollToTop();

  const steps = [
    {
      icon: <FileText className="h-12 w-12 text-red-600" />,
      title: "Pas 1: Escriu o Enganxa el Teu Text",
      description: "Introdueix el text que vols corregir al quadre principal de la nostra eina."
    },
    {
      icon: <Globe className="h-12 w-12 text-red-600" />,
      title: "Pas 2: Selecciona el Dialecte",
      description: "Escull entre català central, valencià o balear segons les teves necessitats."
    },
    {
      icon: <MousePointer className="h-12 w-12 text-red-600" />,
      title: 'Pas 3: Prem el Botó "Corregir Text"',
      description: "Amb un sol clic, la nostra tecnologia avançada revisarà el teu text al moment."
    },
    {
      icon: <CheckCircle2 className="h-12 w-12 text-red-600" />,
      title: "Pas 4: Aplica les Correccions",
      description: "Revisa les suggerències i aplica les que consideris adequades. També podràs veure millores d'estil que optimitzaran la qualitat del teu contingut."
    }
  ];

  return (
    <>
      <Helmet>
        <title>Com Funciona | CorrectorCatala</title>
        <meta 
          name="description" 
          content="Corregeix textos en català en tres passos ✓ Sense instal·lacions ✓ Resultats immediats ✓ Màxima precisió ✓ Comença ara mateix!" 
        />
      </Helmet>

      <main className="max-w-7xl mx-auto px-4 py-12 sm:px-6 lg:px-8">
        {/* Hero Section */}
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-gray-900 mb-6">
            Com Funciona el Corrector Català?
          </h1>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            <strong>El nostre corrector català en línia és tan fàcil d'usar que no perdràs ni un minut aprenent com funciona.</strong> Aquí tens els passos:
          </p>
        </div>

        {/* Steps Section */}
        <div className="max-w-5xl mx-auto">
          <div className="space-y-12">
            {steps.map((step, index) => (
              <div 
                key={index}
                className="flex flex-col md:flex-row items-center md:items-start gap-6 bg-white p-8 rounded-2xl shadow-sm hover:shadow-md transition-shadow"
              >
                <div className="bg-red-50 p-4 rounded-xl">
                  {step.icon}
                </div>
                <div>
                  <h2 className="text-xl font-semibold text-gray-900 mb-2 text-center md:text-left">
                    {step.title}
                  </h2>
                  <p className="text-gray-600 leading-relaxed text-center md:text-left">
                    {step.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* CTA Banner */}
        <div className="mt-16 bg-gradient-to-r from-red-600 to-red-500 text-white rounded-2xl p-8 md:p-12 text-center">
          <div className="flex items-center justify-center mb-6">
            <Zap className="h-12 w-12" />
          </div>
          <h2 className="text-2xl md:text-3xl font-bold mb-4">
            Amb aquests senzills passos, tindràs un text impecable i professional en pocs segons.
          </h2>
          <div className="flex justify-center mt-8">
            <a 
              href="/#"
              className="inline-flex items-center space-x-2 bg-white text-red-600 px-6 py-3 rounded-lg hover:bg-red-50 transition-colors"
            >
              <span>Prova-ho ara mateix!</span>
              <ArrowRight className="h-5 w-5" />
            </a>
          </div>
        </div>
      </main>
    </>
  );
}