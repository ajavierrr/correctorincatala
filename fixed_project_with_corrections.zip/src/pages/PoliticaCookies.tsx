import React from 'react';
import { Helmet } from 'react-helmet-async';
import { useScrollToTop } from '../hooks/useScrollToTop';
import { Cookie, List, Cog, RefreshCcw, Mail } from 'lucide-react';

export function PoliticaCookies() {
  useScrollToTop();

  return (
    <>
      <Helmet>
        <title>Política de Cookies | CorrectorCatala</title>
        <meta 
          name="description" 
          content="Tot sobre les cookies a CorrectorCatala ✓ Què són i per què les fem servir ✓ Control total ✓ Configuració personalitzada ✓ Navega segur" 
        />
        <meta name="robots" content="noindex,follow" />
      </Helmet>

      <main className="max-w-4xl mx-auto px-4 py-12 sm:px-6 lg:px-8">
        {/* Rest of the component remains unchanged */}
      </main>
    </>
  );
}