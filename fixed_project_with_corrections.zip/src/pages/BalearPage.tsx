import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { useScrollToTop } from '../hooks/useScrollToTop';
import { CorrectorTool } from '../components/CorrectorTool';
import { ContentSection } from '../components/ContentSection';
import { defaultSettings, type CorrectorSettings, correctText, type Correction } from '../utils/corrector';
import { 
  CheckCircle2, 
  Target, 
  Clock, 
  Shield,
  FileText,
  Settings2,
  MousePointer,
  GraduationCap,
  Briefcase,
  PenTool,
  Users
} from 'lucide-react';

export function BalearPage() {
  useScrollToTop();
  const [text, setText] = useState('');
  const [corrections, setCorrections] = useState<Correction[]>([]);
  const [settings, setSettings] = useState<CorrectorSettings>(defaultSettings);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  const handleCorrect = () => {
    if (!text.trim()) return;
    const newCorrections = correctText(text, 'balear', settings);
    setCorrections(newCorrections);
  };

  const handleCopy = () => {
    if (!text.trim()) return;
    navigator.clipboard.writeText(text).catch(console.error);
  };

  const handleClear = () => {
    setText('');
    setCorrections([]);
  };

  const schema = {
    "@context": "https://schema.org",
    "@type": "WebPage",
    "name": "Corrector Balear Ortografia i Gramàtica en Línia",
    "description": "El millor corrector per al català balear ✓ Adaptat a les variants insulars ✓ Ortografia i gramàtica perfectes ✓ Resultats immediats ✓ Prova'l ara!",
    "url": "https://correctorcatala.cat/corrector-balear",
    "isPartOf": {
      "@type": "WebSite",
      "name": "Corrector Balear",
      "url": "https://correctorcatala.cat/corrector-balear"
    }
  };

  return (
    <>
      <Helmet>
        <title>Corrector Balear | Ortografia i Gramàtica en Línia</title>
        <meta 
          name="description" 
          content="El millor corrector per al català balear ✓ Adaptat a les variants insulars ✓ Ortografia i gramàtica perfectes ✓ Resultats immediats ✓ Prova'l ara!" 
        />
        <link rel="canonical" href="https://correctorcatala.cat/corrector-balear" />
        <script type="application/ld+json">
          {JSON.stringify(schema)}
        </script>
      </Helmet>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Hero Section */}
        <div className="py-12 text-center">
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-gray-900 tracking-tight mb-6">
            Corrector Balear | Ortografia i Gramàtica en Línia
          </h1>
          <p className="text-lg text-gray-600 leading-relaxed max-w-3xl mx-auto">
            <strong>Vols escriure en la variant balear sense errors?</strong> El nostre corrector balear 
            en línia és la teva eina perfecta per a textos impecables en <strong>mallorquí, menorquí 
            o eivissenc</strong>. Una solució ràpida i precisa adaptada a les particularitats de les Illes.
          </p>
        </div>

        {/* Corrector Tool */}
        <section className="py-12">
          <CorrectorTool
            text={text}
            dialect="balear"
            corrections={corrections}
            onTextChange={setText}
            onDialectChange={() => {}}
            onCorrect={handleCorrect}
            onCopy={handleCopy}
            onClear={handleClear}
            onOpenSettings={() => setIsSettingsOpen(true)}
          />
        </section>

        {/* Main Features */}
        <div className="py-12">
          <div className="grid md:grid-cols-2 gap-8">
            {[
              {
                icon: <CheckCircle2 className="h-6 w-6 text-red-500" />,
                title: "Corregir errors ortogràfics i gramaticals",
                description: "Detectam i corregim errors de manera instantània"
              },
              {
                icon: <Target className="h-6 w-6 text-red-500" />,
                title: "Verificar la unitat",
                description: "Asseguram que els teus textos siguin clars i correctes"
              },
              {
                icon: <Clock className="h-6 w-6 text-red-500" />,
                title: "Millora instantània",
                description: "Resultats immediats sense esperes"
              },
              {
                icon: <Shield className="h-6 w-6 text-red-500" />,
                title: "Assegurar la correcció lingüística",
                description: "Garantim la qualitat en tot moment"
              }
            ].map((feature, index) => (
              <div key={index} className="flex items-start space-x-4">
                <div className="flex-shrink-0 bg-red-50 p-3 rounded-lg">
                  {feature.icon}
                </div>
                <div>
                  <h3 className="font-medium text-gray-900">{feature.title}</h3>
                  <p className="text-sm text-gray-500">{feature.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Content Sections */}
        <ContentSection id="per-que" title="Per Què Necessites un Corrector Balear?">
          <p>El dialecte balear és únic, amb les seves pròpies formes i regles. El nostre corrector t'ajuda a:</p>
          <ul>
            <li><strong>Evitar errors ortogràfics</strong> típics del balear.</li>
            <li><strong>Usar correctament</strong> les formes pròpies de cada illa.</li>
            <li><strong>Escriure amb confiança</strong> en qualsevol situació.</li>
          </ul>
        </ContentSection>

        <ContentSection id="caracteristiques" title="Característiques Principals">
          <p>El nostre corrector balear t'ofereix tot el que necessites:</p>
          <ul>
            <li><strong>Ortografia Perfecta:</strong> Detecta i corregeix cada falta al moment.</li>
            <li><strong>Gramàtica Avançada:</strong> Conjugacions i concordances sempre correctes.</li>
            <li><strong>Adaptació Dialectal:</strong> Compatible amb totes les variants illenques.</li>
            <li><strong>Fàcil d'Usar:</strong> Al mòbil, ordinador o tauleta.</li>
            <li><strong>Suggeriments Intel·ligents:</strong> Per a textos més naturals i fluids.</li>
          </ul>
        </ContentSection>

        <ContentSection id="per-que-triar" title="Per Què Triar el Nostre Corrector?">
          <ul>
            <li><strong>Resultats Immediats:</strong> Veus les correccions mentre escrius.</li>
            <li><strong>Qualitat Garantida:</strong> Seguim les normes oficials del balear.</li>
            <li><strong>Sempre Disponible:</strong> Accedeix des de qualsevol dispositiu.</li>
          </ul>
        </ContentSection>

        <ContentSection id="perfecte" title="Perfecte per a Tothom">
          <p>El nostre corrector balear s'adapta a les teves necessitats:</p>
          <ul>
            <li><strong>Estudiants:</strong> Treballs i projectes sense faltes.</li>
            <li><strong>Professionals:</strong> Correus i informes impecables.</li>
            <li><strong>Particulars:</strong> Missatges i posts perfectes.</li>
          </ul>
        </ContentSection>

        <ContentSection id="on-usar" title="On el Pots Fer Servir?">
          <ul>
            <li><strong>Àmbit Acadèmic:</strong> Per a treballs i projectes.</li>
            <li><strong>Entorn Professional:</strong> Informes i comunicacions.</li>
            <li><strong>Xarxes Socials:</strong> Posts en balear sense errors.</li>
            <li><strong>Comunicacions Personals:</strong> Missatges sempre correctes.</li>
          </ul>
        </ContentSection>

        <ContentSection id="millora" title="Millora la Teva Escriptura en Balear">
          <p><strong>Dona el salt a una escriptura professional</strong> amb el nostre corrector balear en línia. Fàcil, ràpid i adaptat a les particularitats de les Illes.</p>
          <p><strong>Comença ara!</strong> Descobreix com és de fàcil escriure en balear sense errors.</p>
        </ContentSection>
      </main>
    </>
  );
}