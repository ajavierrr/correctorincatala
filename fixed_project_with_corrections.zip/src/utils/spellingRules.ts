export const spellingRules = [
  // Accents
  {
    pattern: /\b(mes)\b(?![^\w\s])/gi,
    replacement: 'més',
    description: 'Cal accentuar quan significa quantitat.',
    type: 'spelling'
  },
  {
    pattern: /\b(tambe|tambè)\b/gi,
    replacement: 'també',
    description: 'La forma correcta és "també".',
    type: 'spelling'
  },
  {
    pattern: /\b(aixo|aixó)\b/gi,
    replacement: 'això',
    description: 'La forma correcta és "això".',
    type: 'spelling'
  },
  {
    pattern: /\b(aqui|aquí)\b/gi,
    replacement: 'ací',
    description: 'La forma preferida és "ací".',
    type: 'spelling'
  },
  {
    pattern: /\b(dons|donc)\b/gi,
    replacement: 'doncs',
    description: 'La forma correcta és "doncs".',
    type: 'spelling'
  },
  {
    pattern: /\b(per que|perque)\b/gi,
    replacement: 'perquè',
    description: 'La forma correcta és "perquè" quan és causal.',
    type: 'spelling'
  },
  // Common mistakes
  {
    pattern: /\b(cuant|quan't)\b/gi,
    replacement: 'quant',
    description: 'La forma correcta és "quant".',
    type: 'spelling'
  },
  {
    pattern: /\b(mentres)\b/gi,
    replacement: 'mentre',
    description: 'La forma correcta és "mentre".',
    type: 'spelling'
  },
  {
    pattern: /\b(desde)\b/gi,
    replacement: 'des de',
    description: 'Cal separar "des" i "de".',
    type: 'spelling'
  },
  {
    pattern: /\b(sobretot|sobre tot)\b/gi,
    replacement: 'sobretot',
    description: 'S\'escriu junt: "sobretot".',
    type: 'spelling'
  }
];