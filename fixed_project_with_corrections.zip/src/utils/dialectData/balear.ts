export const balearRules = {
  // Reglas ortográficas específicas del balear
  spelling: [
    // Terminaciones específicas
    // Grupos consonánticos propios
    // etc.
  ],
  
  // Reglas gramaticales específicas
  grammar: [
    // Conjugaciones verbales baleares
    // Artículos salados
    // Pronombres específicos
    // etc.
  ],
  
  // Vocabulario específico
  vocabulary: [
    // Palabras propias del balear
    // Variantes léxicas
    // etc.
  ]
};

// Aquí necesitaríamos importar un archivo JSON o una base de datos SQLite
// con el conjunto completo de reglas y vocabulario del balear