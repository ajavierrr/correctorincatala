export const valenciaRules = {
  // Reglas ortográficas específicas del valenciano
  spelling: [
    // Terminaciones específicas
    // Grupos consonánticos propios
    // etc.
  ],
  
  // Reglas gramaticales específicas
  grammar: [
    // Conjugaciones verbales valencianas
    // Demostrativos
    // Artículos
    // etc.
  ],
  
  // Vocabulario específico
  vocabulary: [
    // Palabras propias del valenciano
    // Variantes léxicas
    // etc.
  ]
};

// Aquí necesitaríamos importar un archivo JSON o una base de datos SQLite
// con el conjunto completo de reglas y vocabulario del valenciano