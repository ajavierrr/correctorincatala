export const centralRules = {
  // Reglas ortográficas específicas del catalán central
  spelling: [
    // Vocales neutras
    // Terminaciones verbales
    // Grupos consonánticos
    // Dígrafos específicos
    // etc.
  ],
  
  // Reglas gramaticales específicas
  grammar: [
    // Conjugaciones verbales
    // Pronombres
    // Preposiciones
    // etc.
  ],
  
  // Vocabulario específico
  vocabulary: [
    // Palabras propias del dialecto central
    // Variantes léxicas
    // etc.
  ]
};

// Aquí necesitaríamos importar un archivo JSON o una base de datos SQLite 
// con el conjunto completo de reglas y vocabulario del catalán central