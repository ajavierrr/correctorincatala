export const dialectRules = {
  central: [
    {
      pattern: /\b(sapiguer)\b/gi,
      replacement: 'saber',
      description: 'En català central, la forma correcta és "saber".',
      type: 'spelling'
    },
    {
      pattern: /\b(duguer)\b/gi,
      replacement: 'dur',
      description: 'En català central, la forma correcta és "dur".',
      type: 'spelling'
    }
  ],
  valencia: [
    // Demonstratives
    {
      pattern: /\b(aquest[ae]s?)\b/gi,
      replacement: (match) => match.replace(/aquest/i, 'este'),
      description: 'En valencià, es prefereix "este/esta/estos/estes".',
      type: 'style'
    },
    // Vocabulary
    {
      pattern: /\b(desenvolupament)\b/gi,
      replacement: 'desenrotllament',
      description: 'En valencià, es prefereix "desenrotllament".',
      type: 'style'
    },
    {
      pattern: /\b(servei)\b/gi,
      replacement: 'servici',
      description: 'En valencià, es prefereix "servici".',
      type: 'style'
    },
    // Verb forms
    {
      pattern: /\b(sigui|siguis|siguem|sigueu|siguin)\b/gi,
      replacement: (match) => {
        const map: { [key: string]: string } = {
          'sigui': 'siga',
          'siguis': 'sigues',
          'siguem': 'sigam',
          'sigueu': 'sigau',
          'siguin': 'siguen'
        };
        return map[match.toLowerCase()] || match;
      },
      description: 'En valencià, s\'utilitza la forma en -a/-e.',
      type: 'grammar'
    }
  ],
  balear: [
    // Articles personals
    {
      pattern: /\b(en|na)\s+([A-ZÀÁÈÉÌÍÒÓÙÚ])/g,
      replacement: (match, article, name) => {
        return `${article} ${name}`;
      },
      description: 'En balear, s\'usen els articles personals en/na.',
      type: 'grammar'
    },
    {
      pattern: /\b(ca)\b(?=\s+[A-ZÀÁÈÉÌÍÒÓÙÚ])/g,
      replacement: 'can',
      description: 'En balear, davant noms propis cal dir "can".',
      type: 'grammar'
    },
    // Verb forms
    {
      pattern: /\b(som|ets|és|som|sou|són)\b/gi,
      replacement: (match) => {
        const map: { [key: string]: string } = {
          'som': 'som',
          'ets': 'ets',
          'és': 'és',
          'som': 'som',
          'sou': 'sou',
          'són': 'són'
        };
        return map[match.toLowerCase()] || match;
      },
      description: 'Formes verbals pròpies del balear.',
      type: 'grammar'
    }
  ]
};