export interface Correction {
  original: string;
  suggestion: string;
  description: string;
  position: number;
  type: 'spelling' | 'grammar' | 'style';
}

export interface CorrectorSettings {
  checkGrammar: boolean;
  checkStyle: boolean;
  checkSpelling: boolean;
  autoDetectDialect: boolean;
}

export const defaultSettings: CorrectorSettings = {
  checkGrammar: true,
  checkStyle: true,
  checkSpelling: true,
  autoDetectDialect: true
};