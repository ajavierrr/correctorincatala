export interface Rule {
  pattern: RegExp;
  check: (text: string, match: RegExpExecArray) => boolean;
  suggestion: string | ((match: RegExpExecArray) => string);
  description: string;
  type: 'spelling' | 'grammar' | 'style';
  dialect?: string[];
}

export interface GrammarRule extends Rule {
  type: 'grammar';
  category: 'concordance' | 'verb' | 'preposition' | 'article' | 'pronoun';
}

export interface StyleRule extends Rule {
  type: 'style';
  category: 'clarity' | 'formality' | 'regional';
}

export interface SpellingRule extends Rule {
  type: 'spelling';
  category: 'accent' | 'common' | 'dialectal';
}