import levenshtein from 'fast-levenshtein';

export function findClosestMatch(word: string, dictionary: string[]): string {
  let minDistance = Infinity;
  let closestWord = word;

  dictionary.forEach(dictWord => {
    const distance = levenshtein.get(word.toLowerCase(), dictWord.toLowerCase());
    if (distance < minDistance) {
      minDistance = distance;
      closestWord = dictWord;
    }
  });

  return closestWord;
}

export function getSuggestions(word: string, dictionary: string[], maxDistance: number = 2): string[] {
  return dictionary.filter(dictWord => {
    const distance = levenshtein.get(word.toLowerCase(), dictWord.toLowerCase());
    return distance <= maxDistance;
  });
}