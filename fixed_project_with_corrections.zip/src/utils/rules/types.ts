export interface Rule {
  pattern: RegExp;
  check: (text: string, match: RegExpExecArray) => boolean;
  suggestion: string | ((match: RegExpExecArray) => string);
  description: string;
  type: 'spelling' | 'grammar' | 'style';
}