import { Rule } from './types';

export const dialectRules: Record<string, Rule[]> = {
  central: [
    // Spelling rules
    {
      pattern: /\b(sapiguer)\b/gi,
      check: () => true,
      suggestion: 'saber',
      description: 'En català central, la forma correcta és "saber".',
      type: 'spelling'
    },
    {
      pattern: /\b(duguer)\b/gi,
      check: () => true,
      suggestion: 'dur',
      description: 'En català central, la forma correcta és "dur".',
      type: 'spelling'
    },
    // Grammar rules
    {
      pattern: /\b(tinc|tens|té|tenim|teniu|tenen)\s+que\b/gi,
      check: () => true,
      suggestion: (match) => {
        const map: { [key: string]: string } = {
          'tinc': 'he',
          'tens': 'has',
          'té': 'ha',
          'tenim': 'hem',
          'teniu': 'heu',
          'tenen': 'han'
        };
        return `${map[match[1].toLowerCase()]} de`;
      },
      description: 'Cal usar "haver de" en lloc de "tenir que".',
      type: 'grammar'
    },
    {
      pattern: /\b(al|pels|dels)\s+(\d{4})\b/gi,
      check: () => true,
      suggestion: (match) => `el ${match[2]}`,
      description: 'Els anys no porten article amb preposició.',
      type: 'grammar'
    }
  ],
  valencia: [
    // Style rules
    {
      pattern: /\b(aquest[ae]s?)\b/gi,
      check: () => true,
      suggestion: (match) => match[0].replace(/aquest/i, 'este'),
      description: 'En valencià, es prefereix "este/esta/estos/estes".',
      type: 'style'
    },
    {
      pattern: /\b(desenvolupament)\b/gi,
      check: () => true,
      suggestion: 'desenrotllament',
      description: 'En valencià, es prefereix "desenrotllament".',
      type: 'style'
    },
    {
      pattern: /\b(servei)\b/gi,
      check: () => true,
      suggestion: 'servici',
      description: 'En valencià, es prefereix "servici".',
      type: 'style'
    },
    // Grammar rules
    {
      pattern: /\b(sigui|siguis|siguem|sigueu|siguin)\b/gi,
      check: () => true,
      suggestion: (match) => {
        const map: { [key: string]: string } = {
          'sigui': 'siga',
          'siguis': 'sigues',
          'siguem': 'sigam',
          'sigueu': 'sigau',
          'siguin': 'siguen'
        };
        return map[match[0].toLowerCase()] || match[0];
      },
      description: 'En valencià, s\'utilitza la forma en -a/-e.',
      type: 'grammar'
    },
    {
      pattern: /\b(tingui|tinguis|tinguem|tingueu|tinguin)\b/gi,
      check: () => true,
      suggestion: (match) => {
        const map: { [key: string]: string } = {
          'tingui': 'tinga',
          'tinguis': 'tingues',
          'tinguem': 'tingam',
          'tingueu': 'tingau',
          'tinguin': 'tinguen'
        };
        return map[match[0].toLowerCase()] || match[0];
      },
      description: 'En valencià, s\'utilitza la forma en -a/-e.',
      type: 'grammar'
    }
  ],
  balear: [
    // Grammar rules
    {
      pattern: /\b(en|na)\s+([A-ZÀÁÈÉÌÍÒÓÙÚ])/g,
      check: () => true,
      suggestion: (match) => match[0],
      description: 'En balear, s\'usen els articles personals en/na.',
      type: 'grammar'
    },
    {
      pattern: /\b(ca)\b(?=\s+[A-ZÀÁÈÉÌÍÒÓÙÚ])/g,
      check: () => true,
      suggestion: 'can',
      description: 'En balear, davant noms propis cal dir "can".',
      type: 'grammar'
    },
    {
      pattern: /\b(som|ets|és|som|sou|són)\b/gi,
      check: () => true,
      suggestion: (match) => {
        const map: { [key: string]: string } = {
          'som': 'som',
          'ets': 'ets',
          'és': 'és',
          'sou': 'sou',
          'són': 'són'
        };
        return map[match[0].toLowerCase()] || match[0];
      },
      description: 'Formes verbals pròpies del balear.',
      type: 'grammar'
    },
    // Style rules
    {
      pattern: /\b(nin[ae]s?)\b/gi,
      check: () => true,
      suggestion: (match) => match[0],
      description: 'Forma correcta en català balear.',
      type: 'style'
    },
    {
      pattern: /\b(al·lot[ae]s?)\b/gi,
      check: () => true,
      suggestion: (match) => match[0],
      description: 'Forma correcta en català balear.',
      type: 'style'
    }
  ]
};