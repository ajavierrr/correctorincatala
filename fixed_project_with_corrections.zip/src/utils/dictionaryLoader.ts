import Database from 'better-sqlite3';
import { join } from 'path';

interface DictionaryEntry {
  word: string;
  dialect: string;
  category?: string;
  definition?: string;
}

class DictionaryLoader {
  private static instance: DictionaryLoader;
  private db: Database.Database;
  private dictionaries: Map<string, Set<string>>;

  private constructor() {
    this.db = new Database('src/data/dictionaries.db');
    this.dictionaries = new Map();
    this.loadDictionaries();
  }

  public static getInstance(): DictionaryLoader {
    if (!DictionaryLoader.instance) {
      DictionaryLoader.instance = new DictionaryLoader();
    }
    return DictionaryLoader.instance;
  }

  private loadDictionaries() {
    const dialects = ['central', 'valencia', 'balear'];
    
    dialects.forEach(dialect => {
      const words = this.db.prepare(
        'SELECT word FROM dictionary WHERE dialect = ?'
      ).all(dialect);
      
      this.dictionaries.set(
        dialect, 
        new Set(words.map(row => row.word))
      );
    });
  }

  public getDictionary(dialect: string): Set<string> {
    return this.dictionaries.get(dialect) || new Set();
  }

  public isWordValid(word: string, dialect: string): boolean {
    const dictionary = this.getDictionary(dialect);
    return dictionary.has(word.toLowerCase());
  }

  public getSuggestions(word: string, dialect: string): string[] {
    const dictionary = Array.from(this.getDictionary(dialect));
    return dictionary.filter(dictWord => {
      const distance = levenshtein.get(word.toLowerCase(), dictWord.toLowerCase());
      return distance <= 2;
    });
  }
}

export const dictionaryLoader = DictionaryLoader.getInstance();