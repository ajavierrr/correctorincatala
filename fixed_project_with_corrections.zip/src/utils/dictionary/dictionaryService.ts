import { dialectWords } from './dialectWords';
import levenshtein from 'fast-levenshtein';
import type { Dialect } from '../corrector/types';

export class DictionaryService {
  private static instance: DictionaryService;
  private dictionaries: Map<string, Set<string>>;

  private constructor() {
    this.dictionaries = new Map();
    this.initializeDictionaries();
  }

  public static getInstance(): DictionaryService {
    if (!DictionaryService.instance) {
      DictionaryService.instance = new DictionaryService();
    }
    return DictionaryService.instance;
  }

  private initializeDictionaries() {
    Object.entries(dialectWords).forEach(([dialect, words]) => {
      this.dictionaries.set(dialect, new Set(words));
    });
  }

  public isWordValid(word: string, dialect: Dialect): boolean {
    const dictionary = this.dictionaries.get(dialect);
    if (!dictionary) return false;
    return dictionary.has(word.toLowerCase());
  }

  public getSuggestions(word: string, dialect: Dialect, maxDistance: number = 2): string[] {
    const dictionary = this.dictionaries.get(dialect);
    if (!dictionary) return [];

    const suggestions = Array.from(dictionary)
      .filter(dictWord => {
        const distance = levenshtein.get(word.toLowerCase(), dictWord.toLowerCase());
        return distance <= maxDistance;
      })
      .sort((a, b) => {
        const distA = levenshtein.get(word.toLowerCase(), a.toLowerCase());
        const distB = levenshtein.get(word.toLowerCase(), b.toLowerCase());
        return distA - distB;
      });

    return suggestions.slice(0, 3);
  }

  public detectDialect(text: string): Dialect {
    const words = text.toLowerCase().split(/\s+/);
    const scores = {
      central: 0,
      valencia: 0,
      balear: 0
    };

    words.forEach(word => {
      for (const [dialect, dictionary] of this.dictionaries) {
        if (dictionary.has(word)) {
          scores[dialect as keyof typeof scores]++;
        }
      }
    });

    const maxScore = Math.max(...Object.values(scores));
    const detectedDialect = Object.entries(scores)
      .find(([_, score]) => score === maxScore)?.[0] as Dialect || 'central';

    return detectedDialect;
  }
}

export const dictionaryService = DictionaryService.getInstance();