export const dialectPatterns = {
  central: {
    articles: [
      /\b(el|la|els|les)\b/gi,
      /\b(un|una|uns|unes)\b/gi
    ],
    pronouns: [
      /\b(em|et|es|ens|us|es)\b/gi,
      /\b(el|la|els|les|ho|en|hi)\b/gi
    ],
    prepositions: [
      /\b(a|amb|de|en|per)\b/gi
    ],
    contractions: [
      /\b(al|als|del|dels|pel|pels)\b/gi
    ]
  },
  valencia: {
    articles: [
      /\b(el|la|els|les)\b/gi,
      /\b(un|una|uns|unes)\b/gi
    ],
    pronouns: [
      /\b(em|et|es|ens|vos|es)\b/gi,
      /\b(el|la|els|les|ho|en|hi)\b/gi
    ],
    prepositions: [
      /\b(a|amb|de|en|per)\b/gi
    ],
    contractions: [
      /\b(al|als|del|dels|pel|pels)\b/gi
    ]
  },
  balear: {
    articles: [
      /\b(es|sa|ses)\b/gi,
      /\b(un|una|uns|unes)\b/gi,
      /\b(en|na)\b/gi
    ],
    pronouns: [
      /\b(em|et|es|ens|vos|es)\b/gi,
      /\b(el|la|els|les|ho|en|hi)\b/gi
    ],
    prepositions: [
      /\b(a|amb|de|en|per)\b/gi
    ],
    contractions: [
      /\b(al|als|del|dels|pel|pels)\b/gi
    ]
  }
};