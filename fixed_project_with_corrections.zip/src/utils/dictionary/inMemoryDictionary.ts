import { dialectWords } from './dialectWords';

export class InMemoryDictionary {
  private static instance: InMemoryDictionary;
  private dictionaries: Map<string, Set<string>>;

  private constructor() {
    this.dictionaries = new Map();
    this.initializeDictionaries();
  }

  public static getInstance(): InMemoryDictionary {
    if (!InMemoryDictionary.instance) {
      InMemoryDictionary.instance = new InMemoryDictionary();
    }
    return InMemoryDictionary.instance;
  }

  private initializeDictionaries() {
    Object.entries(dialectWords).forEach(([dialect, words]) => {
      this.dictionaries.set(dialect, new Set(words));
    });
  }

  public getDictionary(dialect: string): Set<string> {
    return this.dictionaries.get(dialect) || new Set();
  }

  public isWordValid(word: string, dialect: string): boolean {
    const dictionary = this.getDictionary(dialect);
    return dictionary.has(word.toLowerCase());
  }

  public getSuggestions(word: string, dialect: string): string[] {
    const dictionary = Array.from(this.getDictionary(dialect));
    const lowercaseWord = word.toLowerCase();
    
    return dictionary
      .filter(dictWord => {
        const distance = this.levenshteinDistance(lowercaseWord, dictWord.toLowerCase());
        return distance <= 2 && distance > 0;
      })
      .slice(0, 3);
  }

  private levenshteinDistance(a: string, b: string): number {
    if (a.length === 0) return b.length;
    if (b.length === 0) return a.length;

    const matrix = Array(b.length + 1).fill(null).map(() => 
      Array(a.length + 1).fill(null)
    );

    for (let i = 0; i <= a.length; i++) matrix[0][i] = i;
    for (let j = 0; j <= b.length; j++) matrix[j][0] = j;

    for (let j = 1; j <= b.length; j++) {
      for (let i = 1; i <= a.length; i++) {
        const substitutionCost = a[i - 1] === b[j - 1] ? 0 : 1;
        matrix[j][i] = Math.min(
          matrix[j][i - 1] + 1,
          matrix[j - 1][i] + 1,
          matrix[j - 1][i - 1] + substitutionCost
        );
      }
    }

    return matrix[b.length][a.length];
  }
}

export const inMemoryDictionary = InMemoryDictionary.getInstance();