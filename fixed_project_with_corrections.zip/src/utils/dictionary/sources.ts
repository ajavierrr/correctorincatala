export const DICTIONARY_SOURCES = {
  central: {
    name: 'IEC',
    url: 'https://dlc.iec.cat/Results'
  },
  valencia: {
    name: 'AVL',
    url: 'https://www.avl.gva.es/lexicval'
  },
  balear: {
    name: 'UIB',
    url: 'https://www.uib.cat/diccionari'
  }
};

export const GRAMMAR_SOURCES = {
  central: {
    name: 'Optimot',
    url: 'https://aplicacions.llengua.gencat.cat/llc/AppJava/index.html'
  },
  valencia: {
    name: 'Salt',
    url: 'https://salt.gva.es/va/salt'
  },
  balear: {
    name: 'UIB',
    url: 'https://www.uib.cat/gramatica'
  }
};