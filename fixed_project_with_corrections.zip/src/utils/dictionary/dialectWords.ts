export const dialectWords = {
  central: [
    'casa', 'gos', 'gat', 'taula', 'cadira', 'finestra', 'porta', 'llibre',
    'ordinador', 'telèfon', 'cotxe', 'carrer', 'ciutat', 'país', 'món',
    'persona', 'família', 'amic', 'amiga', 'escola', 'universitat', 'feina',
    'menjar', 'beure', 'dormir', 'caminar', 'córrer', 'parlar', 'escoltar',
    'mirar', 'veure', 'sentir', 'pensar', 'creure', 'saber', 'conèixer',
    'estimar', 'viure', 'morir', 'néixer', 'créixer', 'treballar', 'estudiar',
    'aprendre', 'ensenyar', 'ajudar', 'donar', 'rebre', 'comprar', 'vendre'
  ],
  valencia: [
    'casa', 'gos', 'gat', 'taula', 'cadira', 'finestra', 'porta', 'llibre',
    'ordinador', 'telèfon', 'cotxe', 'carrer', 'ciutat', 'país', 'món',
    'persona', 'família', 'amic', 'amiga', 'escola', 'universitat', 'faena',
    'menjar', 'beure', 'dormir', 'caminar', 'córrer', 'parlar', 'escoltar',
    'mirar', 'veure', 'sentir', 'pensar', 'creure', 'saber', 'conéixer',
    'estimar', 'viure', 'morir', 'nàixer', 'créixer', 'treballar', 'estudiar',
    'aprendre', 'ensenyar', 'ajudar', 'donar', 'rebre', 'comprar', 'vendre'
  ],
  balear: [
    'casa', 'ca', 'moix', 'taula', 'cadira', 'finestra', 'porta', 'llibre',
    'ordinador', 'telèfon', 'cotxe', 'carrer', 'ciutat', 'país', 'món',
    'persona', 'família', 'amic', 'amiga', 'escola', 'universitat', 'feina',
    'menjar', 'beure', 'dormir', 'caminar', 'córrer', 'parlar', 'escoltar',
    'mirar', 'veure', 'sentir', 'pensar', 'creure', 'saber', 'conèixer',
    'estimar', 'viure', 'morir', 'néixer', 'créixer', 'fer feina', 'estudiar',
    'aprendre', 'ensenyar', 'ajudar', 'donar', 'rebre', 'comprar', 'vendre'
  ]
};