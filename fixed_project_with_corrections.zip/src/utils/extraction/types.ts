export interface Source {
  name: string;
  url: string;
  type: 'dictionary' | 'grammar' | 'terminology' | 'comprehensive';
  dialect?: string;
}

export interface Word {
  term: string;
  definition?: string;
  category?: string;
  dialect: string;
  source: string;
}

export interface GrammarRule {
  pattern: string;
  replacement: string;
  description: string;
  category: string;
  dialect: string;
  source: string;
}

export interface VerbConjugation {
  infinitive: string;
  tense: string;
  person: string;
  number: string;
  conjugation: string;
  dialect: string;
  source: string;
}