import { Source } from '../types';

export const UIBSource: Source = {
  name: 'Universitat de les Illes Balears',
  url: 'https://www.uib.cat/diccionari',
  type: 'dictionary',
  dialect: 'balear'
};

export async function extractUIBData() {
  // Implementación específica para extraer datos de la UIB
  const words = [];
  const rules = [];
  const conjugations = [];
  
  return { words, rules, conjugations };
}