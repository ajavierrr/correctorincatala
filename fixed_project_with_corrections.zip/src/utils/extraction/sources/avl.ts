import { Source } from '../types';

export const AVLSource: Source = {
  name: 'Acadèmia Valenciana de la Llengua',
  url: 'https://www.avl.gva.es/lexicval',
  type: 'dictionary',
  dialect: 'valencia'
};

export async function extractAVLData() {
  // Implementación específica para extraer datos de la AVL
  const words = [];
  const rules = [];
  const conjugations = [];
  
  return { words, rules, conjugations };
}