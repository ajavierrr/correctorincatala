import { Source } from '../types';

export const IECSource: Source = {
  name: 'Institut d\'Estudis Catalans',
  url: 'https://dlc.iec.cat/Results',
  type: 'dictionary',
  dialect: 'central'
};

export async function extractIECData() {
  // Implementación específica para extraer datos del IEC
  const words = [];
  const rules = [];
  const conjugations = [];
  
  return { words, rules, conjugations };
}