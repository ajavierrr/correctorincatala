import { LinguisticDatabase } from './db/database';
import { extractIECData } from './sources/iec';
import { extractAVLData } from './sources/avl';
import { extractUIBData } from './sources/uib';

export async function extractAllData() {
  const db = new LinguisticDatabase();

  try {
    console.log('Starting data extraction...');

    // Extract from IEC (Català Central)
    const iecData = await extractIECData();
    iecData.words.forEach(word => db.insertWord(word));
    iecData.rules.forEach(rule => db.insertGrammarRule(rule));
    iecData.conjugations.forEach(conj => db.insertVerbConjugation(conj));

    // Extract from AVL (Valencià)
    const avlData = await extractAVLData();
    avlData.words.forEach(word => db.insertWord(word));
    avlData.rules.forEach(rule => db.insertGrammarRule(rule));
    avlData.conjugations.forEach(conj => db.insertVerbConjugation(conj));

    // Extract from UIB (Balear)
    const uibData = await extractUIBData();
    uibData.words.forEach(word => db.insertWord(word));
    uibData.rules.forEach(rule => db.insertGrammarRule(rule));
    uibData.conjugations.forEach(conj => db.insertVerbConjugation(conj));

    console.log('Data extraction completed successfully!');
  } catch (error) {
    console.error('Error during data extraction:', error);
    throw error;
  } finally {
    db.close();
  }
}