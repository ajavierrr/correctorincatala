import Database from 'better-sqlite3';
import { SCHEMA } from './schema';
import { Word, GrammarRule, VerbConjugation } from '../types';

export class LinguisticDatabase {
  private db: Database.Database;

  constructor() {
    this.db = new Database('src/data/linguistic.db');
    this.initialize();
  }

  private initialize() {
    Object.values(SCHEMA).forEach(statement => {
      this.db.exec(statement);
    });
  }

  insertWord(word: Word) {
    const stmt = this.db.prepare(`
      INSERT OR REPLACE INTO words (word, dialect, definition, category, source)
      VALUES (@term, @dialect, @definition, @category, @source)
    `);
    return stmt.run(word);
  }

  insertGrammarRule(rule: GrammarRule) {
    const stmt = this.db.prepare(`
      INSERT OR REPLACE INTO grammar_rules 
      (rule, pattern, replacement, dialect, category, description, source)
      VALUES (@pattern, @pattern, @replacement, @dialect, @category, @description, @source)
    `);
    return stmt.run(rule);
  }

  insertVerbConjugation(conjugation: VerbConjugation) {
    const stmt = this.db.prepare(`
      INSERT OR REPLACE INTO verb_conjugations 
      (verb, infinitive, tense, person, number, conjugation, dialect, source)
      VALUES (@infinitive, @infinitive, @tense, @person, @number, @conjugation, @dialect, @source)
    `);
    return stmt.run(conjugation);
  }

  getWordsByDialect(dialect: string): Word[] {
    return this.db.prepare('SELECT * FROM words WHERE dialect = ?').all(dialect);
  }

  getRulesByDialect(dialect: string): GrammarRule[] {
    return this.db.prepare('SELECT * FROM grammar_rules WHERE dialect = ?').all(dialect);
  }

  getConjugationsByDialect(dialect: string): VerbConjugation[] {
    return this.db.prepare('SELECT * FROM verb_conjugations WHERE dialect = ?').all(dialect);
  }

  close() {
    this.db.close();
  }
}