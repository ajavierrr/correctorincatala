interface ContextRule {
  pattern: RegExp;
  check: (text: string, match: RegExpExecArray) => boolean;
  suggestion: string;
  description: string;
}

export class ContextAnalyzer {
  private rules: Map<string, ContextRule[]>;

  constructor() {
    this.rules = new Map();
    this.initializeRules();
  }

  private initializeRules() {
    // Valencia-specific rules
    const valenciaRules: ContextRule[] = [
      {
        pattern: /\b(només|sols)\b/gi,
        check: (text, match) => {
          const prevWords = text.slice(0, match.index).split(/\s+/).slice(-3);
          return prevWords.some(word => /^(tan|molt)$/i.test(word));
        },
        suggestion: 'sols',
        description: 'En aquest context, és preferible usar "sols"'
      }
    ];

    // Balear-specific rules
    const balearRules: ContextRule[] = [
      {
        pattern: /\b(el|la|els|les)\s+([A-Z][a-z]+)\b/g,
        check: (text, match) => {
          return /^[A-Z]/.test(match[2]); // Check if second word is proper noun
        },
        suggestion: (match) => `${match[1] === 'el' ? 'en' : 'na'} ${match[2]}`,
        description: 'Amb noms propis, usar articles personals en/na'
      }
    ];

    this.rules.set('valencia', valenciaRules);
    this.rules.set('balear', balearRules);
  }

  public analyzeContext(text: string, dialect: string): Array<{
    original: string,
    suggestion: string,
    description: string,
    position: number
  }> {
    const suggestions = [];
    const dialectRules = this.rules.get(dialect) || [];

    for (const rule of dialectRules) {
      let match;
      while ((match = rule.pattern.exec(text)) !== null) {
        if (rule.check(text, match)) {
          suggestions.push({
            original: match[0],
            suggestion: typeof rule.suggestion === 'string' 
              ? rule.suggestion 
              : rule.suggestion(match),
            description: rule.description,
            position: match.index
          });
        }
      }
    }

    return suggestions;
  }
}

export const contextAnalyzer = new ContextAnalyzer();