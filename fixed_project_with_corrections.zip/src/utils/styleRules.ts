export const styleRules = [
  // Superlativos
  {
    pattern: /\b(molt|molta|molts|moltes)\s+(gran|grans)\b/gi,
    replacement: 'grandíssim',
    description: 'Es pot utilitzar el superlatiu.',
    type: 'style'
  },
  // Redundancias
  {
    pattern: /\b(pujar|baixar)\s+(amunt|avall)\b/gi,
    replacement: (match, verb) => verb,
    description: 'Redundància innecessària.',
    type: 'style'
  },
  // Expresiones mejorables
  {
    pattern: /\b(fer|realitzar)\s+una\s+(anàlisi|investigació|recerca)\b/gi,
    replacement: (match, _, noun) => `analitzar|investigar|cercar`,
    description: 'Es pot utilitzar el verb directament.',
    type: 'style'
  },
  // Locuciones
  {
    pattern: /\b(al|en)\s+respecte\b/gi,
    replacement: 'respecte a això',
    description: 'Expressió més natural.',
    type: 'style'
  },
  // Pleonasmos
  {
    pattern: /\b(entrar|sortir)\s+(dins|fora)\b/gi,
    replacement: (match, verb) => verb,
    description: 'Pleonasme innecessari.',
    type: 'style'
  }
];