export const grammarRules = [
  // Verb conjugation
  {
    pattern: /\b(tinc|tens|tenim|teniu|tenen) que\b/gi,
    replacement: (match) => {
      if (!match) return match;
      const map: { [key: string]: string } = {
        'tinc': 'he',
        'tens': 'has',
        'tenim': 'hem',
        'teniu': 'heu',
        'tenen': 'han'
      };
      const verb = match.split(' ')[0].toLowerCase();
      return `${map[verb] || verb} de`;
    },
    description: 'Cal usar "haver de" en lloc de "tenir que".',
    type: 'grammar'
  },
  // Prepositions
  {
    pattern: /\b(al) (\d{4})\b/gi,
    replacement: 'el $2',
    description: 'Els anys no porten la preposició "a".',
    type: 'grammar'
  },
  {
    pattern: /\b(en) (el|la|els|les)\b/gi,
    replacement: (match, p1, p2) => {
      if (!p2) return match;
      if (p2.toLowerCase() === 'el') return 'al';
      if (p2.toLowerCase() === 'els') return 'als';
      return match;
    },
    description: 'Cal usar la contracció "al/als" en lloc de "en el/en els".',
    type: 'grammar'
  },
  // Articles
  {
    pattern: /\b(el|la|els|les) ([aeiouàèéíòóúh])/gi,
    replacement: (match, article, letter) => {
      if (!article || !letter) return match;
      if (/^[aeiouàèéíòóúh]/i.test(letter)) {
        return (article.toLowerCase() === 'el' ? "l'" : article) + letter;
      }
      return match;
    },
    description: 'Cal apostrofar davant de vocal o h muda.',
    type: 'grammar'
  },
  // Pronouns
  {
    pattern: /\b(em|et|es|ens|us|es) (he|has|ha|hem|heu|han)\b/gi,
    replacement: (match, pronoun, verb) => {
      if (!pronoun || !verb) return match;
      const firstLetter = verb.charAt(0);
      if (/[aeiouàèéíòóúh]/i.test(firstLetter)) {
        return `${pronoun.slice(0, -1)}'${verb}`;
      }
      return match;
    },
    description: 'Cal apostrofar els pronoms febles davant de verb començat en vocal.',
    type: 'grammar'
  }
];