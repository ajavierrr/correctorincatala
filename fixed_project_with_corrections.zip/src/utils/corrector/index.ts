export { CatalanCorrector as default } from './CatalanCorrector';
export * from './types';
export * from './CatalanCorrector';