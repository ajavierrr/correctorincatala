export class TextValidator {
  public static isValidText(text: string | undefined | null): boolean {
    return typeof text === 'string' && text.trim().length > 0;
  }

  public static isValidWord(word: string | undefined | null): boolean {
    return typeof word === 'string' && /^[a-zàáèéìíòóùúçñ·'-]+$/i.test(word);
  }

  public static sanitizeText(text: string): string {
    if (!this.isValidText(text)) return '';
    return text
      .trim()
      .replace(/\s+/g, ' ') // Normalize whitespace
      .replace(/[^\w\sàáèéìíòóùúçñ·'-]/g, ''); // Remove invalid characters
  }

  public static normalizeWord(word: string): string {
    if (!this.isValidWord(word)) return '';
    return word.toLowerCase().trim();
  }
}