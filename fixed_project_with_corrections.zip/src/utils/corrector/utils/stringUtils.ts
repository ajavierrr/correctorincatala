export function normalizeText(text: string): string {
  return text
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '') // Remove diacritics
    .toLowerCase()
    .trim();
}

export function compareStrings(a: string, b: string): number {
  const normalizedA = normalizeText(a);
  const normalizedB = normalizeText(b);
  return normalizedA.localeCompare(normalizedB);
}

export function escapeRegExp(string: string): string {
  return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

export function createWordBoundaryRegExp(word: string): RegExp {
  const escaped = escapeRegExp(word);
  return new RegExp(`\\b${escaped}\\b`, 'gi');
}