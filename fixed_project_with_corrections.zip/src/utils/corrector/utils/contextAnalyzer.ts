import { Dialect } from '../types';

export interface ContextInfo {
  precedingWords: string[];
  followingWords: string[];
  sentence: string;
}

export class ContextAnalyzer {
  public getContext(text: string, position: number, windowSize: number = 5): ContextInfo {
    const words = text.split(/\s+/);
    let currentPos = 0;
    let wordIndex = 0;

    // Find the word index at the given position
    for (let i = 0; i < words.length; i++) {
      if (currentPos + words[i].length >= position) {
        wordIndex = i;
        break;
      }
      currentPos += words[i].length + 1;
    }

    const start = Math.max(0, wordIndex - windowSize);
    const end = Math.min(words.length, wordIndex + windowSize + 1);

    return {
      precedingWords: words.slice(Math.max(0, wordIndex - windowSize), wordIndex),
      followingWords: words.slice(wordIndex + 1, end),
      sentence: this.extractSentence(text, position)
    };
  }

  private extractSentence(text: string, position: number): string {
    const sentenceEnd = /[.!?]\s+/g;
    const before = text.slice(0, position).split(sentenceEnd).pop() || '';
    const after = text.slice(position).split(sentenceEnd)[0] || '';
    return (before + after).trim();
  }

  public isValidInContext(word: string, context: ContextInfo, dialect: Dialect): boolean {
    // Add dialect-specific context validation rules
    switch (dialect) {
      case 'valencia':
        return this.validateValencianContext(word, context);
      case 'balear':
        return this.validateBalearicContext(word, context);
      default:
        return this.validateCentralContext(word, context);
    }
  }

  private validateValencianContext(word: string, context: ContextInfo): boolean {
    // Add Valencian-specific context rules
    return true;
  }

  private validateBalearicContext(word: string, context: ContextInfo): boolean {
    // Add Balearic-specific context rules
    return true;
  }

  private validateCentralContext(word: string, context: ContextInfo): boolean {
    // Add Central Catalan-specific context rules
    return true;
  }
}