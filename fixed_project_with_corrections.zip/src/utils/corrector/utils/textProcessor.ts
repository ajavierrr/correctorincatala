import { ContextInfo } from '../contextAnalyzer';

export function splitIntoWords(text: string): string[] {
  return text.split(/\b/).filter(word => word.trim().length > 0);
}

export function extractContext(text: string, position: number, windowSize: number = 30): string {
  const start = Math.max(0, position - windowSize / 2);
  const end = Math.min(text.length, position + windowSize / 2);
  return text.substring(start, end);
}

export function getWordContext(text: string, position: number, windowSize: number = 5): ContextInfo {
  const words = text.split(/\s+/);
  let currentPos = 0;
  let wordIndex = 0;

  for (let i = 0; i < words.length; i++) {
    if (currentPos + words[i].length >= position) {
      wordIndex = i;
      break;
    }
    currentPos += words[i].length + 1;
  }

  return {
    precedingWords: words.slice(Math.max(0, wordIndex - windowSize), wordIndex),
    followingWords: words.slice(wordIndex + 1, Math.min(words.length, wordIndex + windowSize + 1)),
    sentence: extractSentence(text, position)
  };
}

export function extractSentence(text: string, position: number): string {
  const sentenceEnd = /[.!?]\s+/g;
  const before = text.slice(0, position).split(sentenceEnd).pop() || '';
  const after = text.slice(position).split(sentenceEnd)[0] || '';
  return (before + after).trim();
}

export function findWordPosition(text: string, word: string, startFrom: number = 0): number {
  const index = text.indexOf(word, startFrom);
  return index >= 0 ? index : text.length;
}