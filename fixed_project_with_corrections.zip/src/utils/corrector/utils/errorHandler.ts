import { errorLogger } from './errorLogger';

export class ErrorHandler {
  public static handleError(error: Error, context: string): void {
    errorLogger.logError(error, context);
    
    // Log additional information if available
    if (error instanceof TypeError) {
      console.warn(`Type error in ${context}:`, error.message);
    }
    
    // Prevent undefined errors from breaking the application
    if (error.message.includes('undefined')) {
      console.warn(`Undefined value detected in ${context}`);
    }
  }

  public static wrapFunction<T>(fn: () => T, context: string): T | undefined {
    try {
      return fn();
    } catch (error) {
      this.handleError(error as Error, context);
      return undefined;
    }
  }

  public static async wrapAsync<T>(promise: Promise<T>, context: string): Promise<T | undefined> {
    try {
      return await promise;
    } catch (error) {
      this.handleError(error as Error, context);
      return undefined;
    }
  }
}