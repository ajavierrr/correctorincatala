export class SafeRegExp {
  public static create(pattern: string, flags?: string): RegExp | null {
    try {
      return new RegExp(pattern, flags);
    } catch (error) {
      console.error('Invalid RegExp pattern:', pattern, error);
      return null;
    }
  }

  public static escape(string: string): string {
    return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  }

  public static test(pattern: RegExp | null, text: string): boolean {
    if (!pattern) return false;
    try {
      return pattern.test(text);
    } catch (error) {
      console.error('Error testing RegExp:', error);
      return false;
    }
  }

  public static exec(pattern: RegExp | null, text: string): RegExpExecArray | null {
    if (!pattern) return null;
    try {
      return pattern.exec(text);
    } catch (error) {
      console.error('Error executing RegExp:', error);
      return null;
    }
  }
}