export class ErrorLogger {
  private static instance: ErrorLogger;
  private errors: Error[] = [];

  private constructor() {}

  public static getInstance(): ErrorLogger {
    if (!ErrorLogger.instance) {
      ErrorLogger.instance = new ErrorLogger();
    }
    return ErrorLogger.instance;
  }

  public logError(error: Error, context?: string): void {
    console.error(`[Corrector Error]${context ? ` [${context}]` : ''}: `, error);
    this.errors.push(error);
  }

  public getErrors(): Error[] {
    return [...this.errors];
  }

  public clearErrors(): void {
    this.errors = [];
  }
}

export const errorLogger = ErrorLogger.getInstance();