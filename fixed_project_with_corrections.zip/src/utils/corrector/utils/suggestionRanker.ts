import levenshtein from 'fast-levenshtein';
import { normalizeText } from './stringUtils';

export interface RankedSuggestion {
  word: string;
  score: number;
}

export class SuggestionRanker {
  public rankSuggestions(original: string, suggestions: string[]): RankedSuggestion[] {
    const normalizedOriginal = normalizeText(original);
    
    return suggestions
      .map(suggestion => ({
        word: suggestion,
        score: this.calculateScore(normalizedOriginal, normalizeText(suggestion))
      }))
      .sort((a, b) => b.score - a.score);
  }

  private calculateScore(original: string, suggestion: string): number {
    const levenshteinDistance = levenshtein.get(original, suggestion);
    const lengthDifference = Math.abs(original.length - suggestion.length);
    const prefixMatchLength = this.commonPrefixLength(original, suggestion);
    
    // Weight different factors
    const distanceWeight = 0.4;
    const lengthWeight = 0.3;
    const prefixWeight = 0.3;

    const distanceScore = 1 / (1 + levenshteinDistance);
    const lengthScore = 1 / (1 + lengthDifference);
    const prefixScore = prefixMatchLength / Math.max(original.length, suggestion.length);

    return (
      distanceScore * distanceWeight +
      lengthScore * lengthWeight +
      prefixScore * prefixWeight
    );
  }

  private commonPrefixLength(str1: string, str2: string): number {
    let i = 0;
    while (i < str1.length && i < str2.length && str1[i] === str2[i]) {
      i++;
    }
    return i;
  }
}