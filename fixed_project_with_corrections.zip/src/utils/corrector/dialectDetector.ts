import { Dialect } from './types';

export class DialectDetector {
  private dialectPatterns = {
    valencia: [
      /\b(este|eixe|açò|hui)\b/i,
      /\b(xiquet|meua|teua|seua)\b/i,
      /\b(servici|desenvolupament)\b/i
    ],
    balear: [
      /\b(es|sa|ses|can)\b/i,
      /\b(nin|ca'n|al·lot)\b/i,
      /\b(som|ets|és)\b/i
    ],
    central: [
      /\b(aquest|aquestes|desenvolupament)\b/i,
      /\b(noi|meva|teva|seva)\b/i,
      /\b(servei|avui)\b/i
    ]
  };

  public detectDialect(text: string): Dialect {
    const scores = {
      central: 0,
      valencia: 0,
      balear: 0
    };

    Object.entries(this.dialectPatterns).forEach(([dialect, patterns]) => {
      patterns.forEach(pattern => {
        const matches = text.match(pattern) || [];
        scores[dialect as Dialect] += matches.length;
      });
    });

    const maxScore = Math.max(...Object.values(scores));
    const detectedDialect = Object.entries(scores)
      .find(([_, score]) => score === maxScore)?.[0] as Dialect;

    return detectedDialect || 'central';
  }
}

export const dialectDetector = new DialectDetector();