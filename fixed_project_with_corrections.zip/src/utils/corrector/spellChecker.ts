import levenshtein from 'fast-levenshtein';
import { Dialect, CorrectionResult } from './types';
import { TextProcessor } from './textProcessor';
import { contextAnalyzer } from './contextAnalyzer';
import { dictionaryService } from '../dictionary/dictionaryService';

export class SpellChecker {
  public checkSpelling(text: string, dialect: Dialect): CorrectionResult[] {
    const corrections: CorrectionResult[] = [];
    const words = TextProcessor.splitIntoWords(text);

    words.forEach((word, index) => {
      if (!word || word.length < 2) return;

      if (!dictionaryService.isWordValid(word, dialect)) {
        const suggestions = dictionaryService.getSuggestions(word, dialect);
        const position = text.indexOf(word);
        
        if (suggestions.length > 0) {
          const context = contextAnalyzer.analyzeContext(text, position, dialect);
          
          corrections.push({
            original: word,
            corrected: suggestions[0],
            suggestions,
            type: 'spelling',
            position,
            context: context.sentence,
            confidence: this.calculateConfidence(word, suggestions[0])
          });
        }
      }
    });

    return corrections;
  }

  private calculateConfidence(original: string, suggestion: string): number {
    // Calculate confidence based on Levenshtein distance and word length
    const maxLength = Math.max(original.length, suggestion.length);
    const distance = levenshtein.get(original.toLowerCase(), suggestion.toLowerCase());
    return Math.max(0, 1 - (distance / maxLength));
  }
}

export const spellChecker = new SpellChecker();