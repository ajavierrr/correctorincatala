import { CorrectionResult } from '../types';

export class CorrectionManager {
  public static applyCorrections(text: string, corrections: CorrectionResult[]): string {
    let result = text;
    
    // Sort corrections in reverse order to maintain correct positions
    corrections
      .sort((a, b) => b.position - a.position)
      .forEach(correction => {
        result = result.slice(0, correction.position) +
          correction.corrected +
          result.slice(correction.position + correction.original.length);
      });

    return result;
  }

  public static mergeCorrectionLists(...lists: CorrectionResult[][]): CorrectionResult[] {
    return lists
      .flat()
      .sort((a, b) => a.position - b.position);
  }

  public static filterDuplicateCorrections(corrections: CorrectionResult[]): CorrectionResult[] {
    const seen = new Set<string>();
    return corrections.filter(correction => {
      const key = `${correction.position}:${correction.original}`;
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  }
}