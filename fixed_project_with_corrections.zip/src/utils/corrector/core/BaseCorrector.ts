import { Dialect, CorrectionResult, CorrectorOptions } from '../types';

export abstract class BaseCorrector {
  protected options: Required<CorrectorOptions>;

  constructor(options?: CorrectorOptions) {
    this.options = {
      dialect: 'central',
      autoDetectDialect: true,
      checkSpelling: true,
      checkGrammar: true,
      checkStyle: true,
      contextWindowSize: 5,
      ...options
    };
  }

  abstract correct(text: string): Promise<{
    corrected: string;
    corrections: CorrectionResult[];
    dialect: Dialect;
  }>;

  protected validateText(text: string): boolean {
    return typeof text === 'string' && text.trim().length > 0;
  }

  protected handleError(error: Error, context: string): void {
    console.error(`Error in ${context}:`, error);
  }
}