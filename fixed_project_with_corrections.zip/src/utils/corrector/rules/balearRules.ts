import { Rule } from '../../rules/types';

export const balearRules: Rule[] = [
  // Articles personals
  {
    pattern: /\b(el|la)\s+([A-ZÀÁÈÉÌÍÒÓÙÚ][a-zàáèéìíòóùú]+)\b/g,
    check: () => true,
    suggestion: (match) => {
      const article = match[1].toLowerCase() === 'el' ? 'en' : 'na';
      return `${article} ${match[2]}`;
    },
    description: 'En balear, s\'usen els articles personals en/na amb noms propis',
    type: 'grammar'
  },
  // Specific vocabulary
  {
    pattern: /\b(ca)\b(?=\s+[A-ZÀÁÈÉÌÍÒÓÙÚ])/g,
    check: () => true,
    suggestion: 'can',
    description: 'En balear, davant noms propis cal dir "can"',
    type: 'grammar'
  },
  // Verb forms
  {
    pattern: /\b(som|ets|és|som|sou|són)\b/gi,
    check: () => true,
    suggestion: (match) => {
      const forms: { [key: string]: string } = {
        'som': 'som',
        'ets': 'ets',
        'és': 'és',
        'sou': 'sou',
        'són': 'són'
      };
      return forms[match[0].toLowerCase()] || match[0];
    },
    description: 'Formes verbals pròpies del balear',
    type: 'grammar'
  },
  // Regional vocabulary
  {
    pattern: /\b(nin[ae]s?)\b/gi,
    check: () => true,
    suggestion: (match) => match[0],
    description: 'Forma correcta en català balear',
    type: 'style'
  },
  {
    pattern: /\b(al·lot[ae]s?)\b/gi,
    check: () => true,
    suggestion: (match) => match[0],
    description: 'Forma correcta en català balear',
    type: 'style'
  },
  // Common mistakes
  {
    pattern: /\b(cossa)\b/gi,
    check: () => true,
    suggestion: 'cosa',
    description: 'La forma correcta és "cosa"',
    type: 'spelling'
  },
  {
    pattern: /\b(borses)\b/gi,
    check: () => true,
    suggestion: 'bosses',
    description: 'La forma correcta és "bosses"',
    type: 'spelling'
  }
];