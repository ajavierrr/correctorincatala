import { Rule } from '../../rules/types';

export const centralRules: Rule[] = [
  // Verb conjugations
  {
    pattern: /\b(sapiguer)\b/gi,
    check: () => true,
    suggestion: 'saber',
    description: 'La forma correcta és "saber"',
    type: 'spelling'
  },
  {
    pattern: /\b(tinc|tens|té|tenim|teniu|tenen)\s+que\b/gi,
    check: () => true,
    suggestion: (match) => {
      const forms: { [key: string]: string } = {
        'tinc': 'he',
        'tens': 'has',
        'té': 'ha',
        'tenim': 'hem',
        'teniu': 'heu',
        'tenen': 'han'
      };
      const verb = match[1].toLowerCase();
      return `${forms[verb] || verb} de`;
    },
    description: 'Cal usar "haver de" en lloc de "tenir que"',
    type: 'grammar'
  },
  // Articles and prepositions
  {
    pattern: /\b(al|pels|dels)\s+(\d{4})\b/gi,
    check: () => true,
    suggestion: (match) => `el ${match[2]}`,
    description: 'Els anys no porten article amb preposició',
    type: 'grammar'
  },
  // Common mistakes
  {
    pattern: /\b(mentres)\b/gi,
    check: () => true,
    suggestion: 'mentre',
    description: 'La forma correcta és "mentre"',
    type: 'spelling'
  },
  {
    pattern: /\b(desde)\b/gi,
    check: () => true,
    suggestion: 'des de',
    description: 'Cal separar "des" i "de"',
    type: 'spelling'
  }
];