import { centralRules } from './centralRules';
import { valenciaRules } from './valenciaRules';
import { balearRules } from './balearRules';
import { Rule } from '../../rules/types';
import { Dialect } from '../types';

export const dialectRules: Record<Dialect, Rule[]> = {
  central: centralRules,
  valencia: valenciaRules,
  balear: balearRules
};