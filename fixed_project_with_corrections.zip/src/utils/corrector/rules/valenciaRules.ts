import { Rule } from '../../rules/types';

export const valenciaRules: Rule[] = [
  // Demonstratives
  {
    pattern: /\b(aquest[ae]s?)\b/gi,
    check: () => true,
    suggestion: (match) => match[0].replace(/aquest/i, 'este'),
    description: 'En valencià, es prefereix "este/esta/estos/estes"',
    type: 'style'
  },
  // Vocabulary
  {
    pattern: /\b(desenvolupament)\b/gi,
    check: () => true,
    suggestion: 'desenrotllament',
    description: 'En valencià, es prefereix "desenrotllament"',
    type: 'style'
  },
  {
    pattern: /\b(servei)\b/gi,
    check: () => true,
    suggestion: 'servici',
    description: 'En valencià, es prefereix "servici"',
    type: 'style'
  },
  // Verb conjugations
  {
    pattern: /\b(sigui|siguis|siguem|sigueu|siguin)\b/gi,
    check: () => true,
    suggestion: (match) => {
      const forms: { [key: string]: string } = {
        'sigui': 'siga',
        'siguis': 'sigues',
        'siguem': 'sigam',
        'sigueu': 'sigau',
        'siguin': 'siguen'
      };
      return forms[match[0].toLowerCase()] || match[0];
    },
    description: 'En valencià, s\'utilitza la forma en -a/-e',
    type: 'grammar'
  },
  // Common expressions
  {
    pattern: /\b(només)\b/gi,
    check: (text, match) => {
      const prevWords = text.slice(0, match.index).split(/\s+/).slice(-3);
      return prevWords.some(word => /^(tan|molt)$/i.test(word));
    },
    suggestion: 'sols',
    description: 'En aquest context, és preferible usar "sols"',
    type: 'style'
  }
];