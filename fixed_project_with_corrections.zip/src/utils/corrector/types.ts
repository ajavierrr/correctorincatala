export type Dialect = 'central' | 'valencia' | 'balear';

export interface ContextInfo {
  precedingWords: string[];
  followingWords: string[];
  sentence: string;
}

export interface CorrectionResult {
  original: string;
  corrected: string;
  suggestions: string[];
  type: 'spelling' | 'grammar' | 'style';
  position: number;
  context?: string;
  confidence?: number;
}

export interface CorrectorOptions {
  dialect?: Dialect;
  autoDetectDialect?: boolean;
  checkSpelling?: boolean;
  checkGrammar?: boolean;
  checkStyle?: boolean;
  contextWindowSize?: number;
}

export interface DictionaryEntry {
  word: string;
  dialect: Dialect;
  category?: string;
  definition?: string;
}

export interface GrammarRule {
  pattern: RegExp;
  replacement: string | ((match: RegExpMatchArray) => string);
  description: string;
  dialect: Dialect;
  category: string;
  confidence?: number;
}