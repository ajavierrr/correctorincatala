import { Correction, Dialect } from './types';
import { dialectRules } from '../rules/dialectRules';
import { extractContext } from './utils/textProcessor';

export class StyleChecker {
  public checkStyle(text: string, dialect: Dialect): Correction[] {
    const corrections: Correction[] = [];
    const rules = dialectRules[dialect] || [];

    rules.forEach(rule => {
      if (rule.type !== 'style') return;

      try {
        const regex = new RegExp(rule.pattern, 'gi');
        let match;
        
        while ((match = regex.exec(text)) !== null) {
          if (rule.check(text, match)) {
            const suggestion = typeof rule.suggestion === 'string' 
              ? rule.suggestion 
              : rule.suggestion(match);

            corrections.push({
              original: match[0],
              suggestion,
              description: rule.description,
              position: match.index,
              type: 'style'
            });
          }
        }
      } catch (error) {
        console.error(`Error applying style rule: ${rule.description}`, error);
      }
    });

    return corrections;
  }
}

export const styleChecker = new StyleChecker();