import { Dialect } from './types';
import { ContextInfo } from './contextAnalyzer';
import { extractContext, splitIntoWords } from './utils/textProcessor';
import { normalizeText } from './utils/stringUtils';
import { ErrorHandler } from './utils/errorHandler';

export class TextAnalyzer {
  private static instance: TextAnalyzer;
  
  private constructor() {}

  public static getInstance(): TextAnalyzer {
    if (!TextAnalyzer.instance) {
      TextAnalyzer.instance = new TextAnalyzer();
    }
    return TextAnalyzer.instance;
  }

  public analyzeText(text: string, dialect: Dialect): TextAnalysis {
    return ErrorHandler.wrapFunction(() => {
      const words = splitIntoWords(text);
      const normalizedText = normalizeText(text);
      
      return {
        wordCount: words.length,
        characterCount: text.length,
        normalizedText,
        dialect,
        sentences: this.extractSentences(text),
        paragraphs: this.extractParagraphs(text)
      };
    }, 'TextAnalyzer.analyzeText') || this.getEmptyAnalysis(dialect);
  }

  public getWordContext(text: string, position: number, windowSize: number = 5): ContextInfo {
    return ErrorHandler.wrapFunction(() => {
      const words = text.split(/\s+/);
      let currentPos = 0;
      let wordIndex = 0;

      for (let i = 0; i < words.length; i++) {
        if (currentPos + words[i].length >= position) {
          wordIndex = i;
          break;
        }
        currentPos += words[i].length + 1;
      }

      return {
        precedingWords: words.slice(Math.max(0, wordIndex - windowSize), wordIndex),
        followingWords: words.slice(wordIndex + 1, Math.min(words.length, wordIndex + windowSize + 1)),
        sentence: extractContext(text, position)
      };
    }, 'TextAnalyzer.getWordContext') || this.getEmptyContext();
  }

  private extractSentences(text: string): string[] {
    return text.match(/[^.!?]+[.!?]+/g) || [];
  }

  private extractParagraphs(text: string): string[] {
    return text.split(/\n\s*\n/).filter(p => p.trim().length > 0);
  }

  private getEmptyAnalysis(dialect: Dialect): TextAnalysis {
    return {
      wordCount: 0,
      characterCount: 0,
      normalizedText: '',
      dialect,
      sentences: [],
      paragraphs: []
    };
  }

  private getEmptyContext(): ContextInfo {
    return {
      precedingWords: [],
      followingWords: [],
      sentence: ''
    };
  }
}

export interface TextAnalysis {
  wordCount: number;
  characterCount: number;
  normalizedText: string;
  dialect: Dialect;
  sentences: string[];
  paragraphs: string[];
}

export const textAnalyzer = TextAnalyzer.getInstance();