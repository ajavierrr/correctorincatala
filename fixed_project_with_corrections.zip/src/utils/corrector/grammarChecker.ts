import { Dialect, CorrectionResult, GrammarRule } from './types';
import { TextProcessor } from './textProcessor';
import { contextAnalyzer } from './contextAnalyzer';
import { dialectRules } from '../rules/dialectRules';

export class GrammarChecker {
  public checkGrammar(text: string, dialect: Dialect): CorrectionResult[] {
    const corrections: CorrectionResult[] = [];
    const rules = dialectRules[dialect] || [];

    rules.forEach(rule => {
      let match;
      const pattern = new RegExp(rule.pattern, 'gi');
      
      while ((match = pattern.exec(text)) !== null) {
        const replacement = typeof rule.replacement === 'string' 
          ? rule.replacement 
          : rule.replacement(match);

        const context = contextAnalyzer.analyzeContext(text, match.index, dialect);

        corrections.push({
          original: match[0],
          corrected: replacement,
          suggestions: [replacement],
          type: 'grammar',
          position: match.index,
          context: context.sentence,
          confidence: rule.confidence || 0.8
        });
      }
    });

    return corrections;
  }
}

export const grammarChecker = new GrammarChecker();