import axios from 'axios';

export type Dialect = 'central' | 'valencia' | 'balear';

interface ApertiumResponse {
  responseData: {
    translatedText: string;
  };
  error?: string;
}

export class ApertiumService {
  private static instance: ApertiumService;
  private readonly baseUrl = 'https://apertium.org/apy/translate';
  
  private readonly dialectMap: Record<Dialect, string> = {
    central: 'ca',
    valencia: 'ca-valencia',
    balear: 'ca-balear'
  };

  private constructor() {}

  public static getInstance(): ApertiumService {
    if (!ApertiumService.instance) {
      ApertiumService.instance = new ApertiumService();
    }
    return ApertiumService.instance;
  }

  public async correctText(text: string, dialect: Dialect): Promise<string> {
    try {
      const sourceLang = this.dialectMap[dialect];
      const url = `${this.baseUrl}?langpair=${sourceLang}|${sourceLang}&q=${encodeURIComponent(text)}`;
      
      const response = await axios.get<ApertiumResponse>(url);
      
      if (response.data?.responseData?.translatedText) {
        return response.data.responseData.translatedText;
      }
      
      return text;
    } catch (error) {
      console.error('Error in Apertium service:', error);
      return text;
    }
  }
}

export const apertiumService = ApertiumService.getInstance();