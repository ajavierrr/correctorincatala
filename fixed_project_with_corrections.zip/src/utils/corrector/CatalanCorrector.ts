import { Dialect, CorrectionResult, CorrectorOptions } from './types';
import { BaseCorrector } from './core/BaseCorrector';
import { CorrectionManager } from './core/CorrectionManager';
import { dialectDetector } from './dialectDetector';
import { spellChecker } from './spellChecker';
import { grammarChecker } from './grammarChecker';
import { apertiumService } from './services/apertiumService';

export class CatalanCorrector extends BaseCorrector {
  constructor(options?: CorrectorOptions) {
    super(options);
  }

  public async correct(text: string): Promise<{
    corrected: string;
    corrections: CorrectionResult[];
    dialect: Dialect;
  }> {
    if (!this.validateText(text)) {
      return { 
        corrected: text, 
        corrections: [], 
        dialect: this.options.dialect 
      };
    }

    try {
      const dialect = this.options.autoDetectDialect 
        ? dialectDetector.detectDialect(text)
        : this.options.dialect;

      // First, get corrections from our local correctors
      const corrections: CorrectionResult[] = [];

      if (this.options.checkSpelling) {
        corrections.push(...spellChecker.checkSpelling(text, dialect));
      }

      if (this.options.checkGrammar) {
        corrections.push(...grammarChecker.checkGrammar(text, dialect));
      }

      const uniqueCorrections = CorrectionManager.filterDuplicateCorrections(corrections);
      let correctedText = CorrectionManager.applyCorrections(text, uniqueCorrections);

      // Then, use Apertium as a secondary correction layer
      correctedText = await apertiumService.correctText(correctedText, dialect);

      return {
        corrected: correctedText,
        corrections: uniqueCorrections,
        dialect
      };
    } catch (error) {
      this.handleError(error as Error, 'CatalanCorrector.correct');
      return { 
        corrected: text, 
        corrections: [], 
        dialect: this.options.dialect 
      };
    }
  }

  public async getCorrections(text: string): Promise<CorrectionResult[]> {
    if (!this.validateText(text)) {
      return [];
    }

    try {
      const dialect = this.options.autoDetectDialect 
        ? dialectDetector.detectDialect(text)
        : this.options.dialect;

      const corrections: CorrectionResult[] = [];

      if (this.options.checkSpelling) {
        corrections.push(...spellChecker.checkSpelling(text, dialect));
      }

      if (this.options.checkGrammar) {
        corrections.push(...grammarChecker.checkGrammar(text, dialect));
      }

      return CorrectionManager.filterDuplicateCorrections(corrections);
    } catch (error) {
      this.handleError(error as Error, 'CatalanCorrector.getCorrections');
      return [];
    }
  }
}

export default CatalanCorrector;