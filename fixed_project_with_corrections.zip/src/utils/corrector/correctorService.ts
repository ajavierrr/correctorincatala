import { dictionaryService } from '../dictionary/dictionaryService';
import { Correction, CorrectorSettings } from '../types/correction';
import { dialectRules } from '../rules/dialectRules';

export class CorrectorService {
  private static instance: CorrectorService;

  private constructor() {}

  public static getInstance(): CorrectorService {
    if (!CorrectorService.instance) {
      CorrectorService.instance = new CorrectorService();
    }
    return CorrectorService.instance;
  }

  public correctText(
    text: string,
    dialect: string,
    settings: CorrectorSettings
  ): Correction[] {
    if (!text.trim()) return [];

    const corrections: Correction[] = [];
    const detectedDialect = settings.autoDetectDialect 
      ? dictionaryService.detectDialect(text)
      : dialect;

    // Spelling check
    if (settings.checkSpelling) {
      const words = text.split(/\s+/);
      words.forEach((word, index) => {
        if (!word || word.length < 2) return;
        
        if (!dictionaryService.isWordValid(word, detectedDialect)) {
          const suggestions = dictionaryService.getSuggestions(word, detectedDialect);
          if (suggestions.length > 0) {
            corrections.push({
              original: word,
              suggestion: suggestions[0],
              description: `Possible error ortogràfic en ${detectedDialect}`,
              position: text.indexOf(word),
              type: 'spelling'
            });
          }
        }
      });
    }

    // Grammar and style checks
    if (settings.checkGrammar || settings.checkStyle) {
      const rules = dialectRules[detectedDialect] || [];
      rules.forEach(rule => {
        const regex = new RegExp(rule.pattern, 'gi');
        let match;
        
        while ((match = regex.exec(text)) !== null) {
          if (rule.check(text, match)) {
            corrections.push({
              original: match[0],
              suggestion: typeof rule.suggestion === 'string' 
                ? rule.suggestion 
                : rule.suggestion(match),
              description: rule.description,
              position: match.index,
              type: settings.checkGrammar ? 'grammar' : 'style'
            });
          }
        }
      });
    }

    return corrections.sort((a, b) => a.position - b.position);
  }
}

export const correctorService = CorrectorService.getInstance();