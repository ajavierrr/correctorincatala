import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { ErrorBoundary } from './components/ErrorBoundary';
import { HomePage } from './pages/HomePage';
import { WhyChooseUsPage } from './pages/WhyChooseUsPage';
import { FeaturesPage } from './pages/FeaturesPage';
import { HowItWorksPage } from './pages/HowItWorksPage';
import { WhoCanUsePage } from './pages/WhoCanUsePage';
import { FAQPage } from './pages/FAQPage';
import { AvisLegal } from './pages/AvisLegal';
import { PoliticaPrivacitat } from './pages/PoliticaPrivacitat';
import { PoliticaCookies } from './pages/PoliticaCookies';
import { Contacte } from './pages/Contacte';
import { ValenciaPage } from './pages/ValenciaPage';
import { BalearPage } from './pages/BalearPage';
import { CorrectorTest } from './components/CorrectorTest';

export function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 via-white to-red-50">
      <ErrorBoundary>
        <Header />
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/per-que-triar-nos" element={<WhyChooseUsPage />} />
          <Route path="/caracteristiques" element={<FeaturesPage />} />
          <Route path="/com-funciona" element={<HowItWorksPage />} />
          <Route path="/qui-pot-usar-lo" element={<WhoCanUsePage />} />
          <Route path="/faq" element={<FAQPage />} />
          <Route path="/avis-legal" element={<AvisLegal />} />
          <Route path="/politica-privacitat" element={<PoliticaPrivacitat />} />
          <Route path="/politica-cookies" element={<PoliticaCookies />} />
          <Route path="/contacte" element={<Contacte />} />
          <Route path="/corrector-valencia" element={<ValenciaPage />} />
          <Route path="/corrector-balear" element={<BalearPage />} />
          <Route path="/test" element={<CorrectorTest />} />
        </Routes>
        <Footer />
      </ErrorBoundary>
    </div>
  );
}