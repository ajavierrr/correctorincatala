import React, { useState } from 'react';
import { Info, Lock, Settings, AlertCircle } from 'lucide-react';

interface Tab {
  id: string;
  icon: React.ReactNode;
  title: string;
  content: string;
}

export function CorrectorInfo() {
  const [activeTab, setActiveTab] = useState<string | null>(null);

  const tabs: Tab[] = [
    {
      id: 'privacy',
      icon: <Lock className="h-4 w-4" />,
      title: 'Privacitat de les dades',
      content: 'Els textos s\'envien al servidor mitjançant una connexió segura. No s\'emmagatzemen ni els textos ni les correccions. Només es guarden dades estadístiques anònimes com el nombre de caràcters del text i el nombre d\'errors trobats.'
    },
    {
      id: 'options',
      icon: <Settings className="h-4 w-4" />,
      title: 'Opcions',
      content: 'Trieu entre formes generals, valencianes i balears. Fent clic a «Més opcions» podeu configurar altres preferències de correcció (estil, tipografia, diacrítics). Les opcions són més nombroses si seleccioneu les formes valencianes.'
    },
    {
      id: 'results',
      icon: <AlertCircle className="h-4 w-4" />,
      title: 'Resultats',
      content: 'Apareixeran subratllats errors ortogràfics, qüestions gramaticals o tipogràfiques i recomanacions d\'estil. Fent clic en les paraules assenyalades, obtindreu suggeriments de correcció, si n\'hi ha. Els resultats són orientatius i no poden substituir una revisió experta.'
    }
  ];

  return (
    <div className="mt-4 space-y-2">
      <div className="flex items-center space-x-1 text-xs text-gray-500">
        <Info className="h-3 w-3" />
        <span>Feu clic per més informació</span>
      </div>
      <div className="space-y-2">
        {tabs.map((tab) => (
          <div key={tab.id} className="border border-gray-200 rounded-lg">
            <button
              onClick={() => setActiveTab(activeTab === tab.id ? null : tab.id)}
              className="w-full px-4 py-2 flex items-center justify-between text-left hover:bg-gray-50 transition-colors rounded-lg"
            >
              <div className="flex items-center space-x-2">
                {tab.icon}
                <span className="font-medium text-sm">{tab.title}</span>
              </div>
              <svg
                className={`h-5 w-5 transform transition-transform ${
                  activeTab === tab.id ? 'rotate-180' : ''
                }`}
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M19 9l-7 7-7-7"
                />
              </svg>
            </button>
            {activeTab === tab.id && (
              <div className="px-4 py-3 text-sm text-gray-600 border-t border-gray-200 bg-gray-50">
                {tab.content}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}