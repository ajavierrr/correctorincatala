import React from 'react';

declare global {
  interface Window {
    Sddan?: {
      cmp?: {
        displayUI?: () => void;
      };
    };
  }
}

export function CookieConsent() {
  const handleOpenSettings = () => {
    if (window.Sddan?.cmp?.displayUI) {
      window.Sddan.cmp.displayUI();
    }
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 shadow-lg p-4 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-sm text-gray-600">
            Aquest lloc web utilitza cookies per millorar la teva experiència. 
            En continuar navegant, acceptes la nostra política de cookies.
          </p>
          <div className="flex gap-4">
            <button 
              onClick={handleOpenSettings}
              className="text-sm px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
            >
              Configurar cookies
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}