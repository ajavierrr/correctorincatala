import React, { useState } from 'react';
import { Send, Copy, Eraser, Settings2 } from 'lucide-react';
import { CorrectorInfo } from './CorrectorInfo';
import { CatalanCorrector } from '../utils/corrector/CatalanCorrector';
import type { Dialect } from '../utils/corrector/types';

interface CorrectorToolProps {
  text: string;
  dialect: Dialect;
  onTextChange: (text: string) => void;
  onDialectChange: (dialect: Dialect) => void;
  onCopy: () => void;
  onClear: () => void;
  onOpenSettings: () => void;
}

export function CorrectorTool({
  text,
  dialect,
  onTextChange,
  onDialectChange,
  onCopy,
  onClear,
  onOpenSettings
}: CorrectorToolProps) {
  const [correctedText, setCorrectedText] = useState<string>('');
  const [isLoading, setIsLoading] = useState(false);
  const [copySuccess, setCopySuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const corrector = new CatalanCorrector({ dialect });

  const handleCorrect = async () => {
    if (!text.trim()) return;
    
    setIsLoading(true);
    setError(null);
    
    try {
      const result = await corrector.correct(text);
      setCorrectedText(result.corrected);
    } catch (error) {
      console.error('Error correcting text:', error);
      setError('Hi ha hagut un error en corregir el text. Si us plau, torna-ho a provar.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(correctedText || text);
      setCopySuccess(true);
      onCopy();
      setTimeout(() => setCopySuccess(false), 2000);
    } catch (err) {
      console.error('Failed to copy text:', err);
      setError('No s\'ha pogut copiar el text');
    }
  };

  return (
    <div className="bg-white rounded-2xl shadow-xl p-8">
      {/* Dialect Selection */}
      <div className="flex flex-wrap gap-6 mb-6">
        {[
          { value: 'central', label: 'Català central' },
          { value: 'valencia', label: 'Valencià' },
          { value: 'balear', label: 'Balear' }
        ].map(({ value, label }) => (
          <label key={value} className="flex items-center space-x-2 cursor-pointer">
            <input
              type="radio"
              name="dialect"
              value={value}
              checked={dialect === value}
              onChange={(e) => onDialectChange(e.target.value as Dialect)}
              className="text-red-600 focus:ring-red-500"
            />
            <span className="text-gray-700">{label}</span>
          </label>
        ))}
      </div>

      {/* Text Editor */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Original Text */}
        <div className="flex flex-col h-full">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Text original
          </label>
          <textarea
            value={text}
            onChange={(e) => onTextChange(e.target.value)}
            placeholder="Escriu o enganxa el teu text aquí..."
            className="flex-1 w-full p-4 border border-gray-200 rounded-xl focus:ring-2 focus:ring-red-500 focus:border-transparent resize-none min-h-[16rem]"
          />
        </div>

        {/* Corrected Text */}
        <div className="flex flex-col h-full">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Text corregit
          </label>
          <div className="flex-1 w-full p-4 border border-gray-200 rounded-xl bg-gray-50 overflow-auto min-h-[16rem]">
            {correctedText || (
              <span className="text-gray-400 italic">
                El text corregit apareixerà aquí
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Error Message */}
      {error && (
        <div className="mt-4 p-4 bg-red-50 text-red-700 rounded-lg">
          {error}
        </div>
      )}

      {/* Action Buttons */}
      <div className="flex justify-between mt-6">
        <div className="flex space-x-2">
          <button 
            onClick={handleCopy}
            className="p-2 text-gray-400 hover:text-red-600 transition-colors"
            title={copySuccess ? 'Copiat!' : 'Copiar text'}
          >
            <Copy className="h-5 w-5" />
          </button>
          <button 
            onClick={onClear}
            className="p-2 text-gray-400 hover:text-red-600 transition-colors"
            title="Esborrar text"
          >
            <Eraser className="h-5 w-5" />
          </button>
          <button 
            onClick={onOpenSettings}
            className="p-2 text-gray-400 hover:text-red-600 transition-colors"
            title="Configuració"
          >
            <Settings2 className="h-5 w-5" />
          </button>
        </div>

        {/* Correct Button */}
        <button 
          onClick={handleCorrect}
          disabled={isLoading || !text.trim()}
          className="bg-gradient-to-r from-red-600 to-red-500 text-white px-6 py-3 rounded-lg hover:from-red-700 hover:to-red-600 transition-all flex items-center justify-center space-x-2 font-medium shadow-md hover:shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isLoading ? (
            <span className="flex items-center">
              <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Corregint...
            </span>
          ) : (
            <>
              <Send className="h-5 w-5" />
              <span>Corregir text</span>
            </>
          )}
        </button>
      </div>

      <CorrectorInfo />
    </div>
  );
}