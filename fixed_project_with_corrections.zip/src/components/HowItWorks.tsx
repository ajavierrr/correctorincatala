import React from 'react';
import { FileText, Wand2, CheckCircle2 } from 'lucide-react';

export function HowItWorks() {
  const steps = [
    {
      icon: <FileText className="h-8 w-8 text-red-600" />,
      title: "1. Enganxa el text",
      description: "Copia i enganxa el text que vols corregir al quadre de text principal"
    },
    {
      icon: <Wand2 className="h-8 w-8 text-red-600" />,
      title: "2. Selecciona el dialecte",
      description: "Tria entre català central, valencià o balear segons les teves necessitats"
    },
    {
      icon: <CheckCircle2 className="h-8 w-8 text-red-600" />,
      title: "3. Revisa i corregeix",
      description: "Fes clic a 'Corregir text' i revisa les suggerències de millora"
    }
  ];

  return (
    <div className="py-8">
      <h2 className="text-3xl font-bold text-gray-900 mb-6">
        Com Funciona el Corrector Gramatical Català?
      </h2>
      <p className="text-lg text-gray-600 mb-8">
        És molt fàcil! El nostre corrector ortogràfic català en línia et permet millorar els teus textos en només tres passos:
      </p>
      <div className="grid md:grid-cols-3 gap-8">
        {steps.map((step, index) => (
          <div key={index} className="text-center p-6 bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-red-50 mb-4">
              {step.icon}
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">{step.title}</h3>
            <p className="text-gray-600">{step.description}</p>
          </div>
        ))}
      </div>
    </div>
  );
}