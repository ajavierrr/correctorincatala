import React from 'react';
import { X } from 'lucide-react';
import type { CorrectorSettings } from '../utils/corrector';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: CorrectorSettings;
  onSettingsChange: (settings: CorrectorSettings) => void;
}

export function SettingsModal({ 
  isOpen, 
  onClose, 
  settings, 
  onSettingsChange 
}: SettingsModalProps) {
  if (!isOpen) return null;

  const handleChange = (key: keyof CorrectorSettings) => {
    onSettingsChange({
      ...settings,
      [key]: !settings[key]
    });
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center">
      <div className="bg-white rounded-xl p-6 max-w-md w-full mx-4">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-xl font-semibold">Configuració</h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 transition-colors"
          >
            <X className="h-6 w-6" />
          </button>
        </div>

        <div className="space-y-4">
          <label className="flex items-center space-x-3">
            <input
              type="checkbox"
              checked={settings.checkSpelling}
              onChange={() => handleChange('checkSpelling')}
              className="rounded border-gray-300 text-red-600 focus:ring-red-500"
            />
            <span>Revisar ortografia</span>
          </label>

          <label className="flex items-center space-x-3">
            <input
              type="checkbox"
              checked={settings.checkGrammar}
              onChange={() => handleChange('checkGrammar')}
              className="rounded border-gray-300 text-red-600 focus:ring-red-500"
            />
            <span>Revisar gramàtica</span>
          </label>

          <label className="flex items-center space-x-3">
            <input
              type="checkbox"
              checked={settings.checkStyle}
              onChange={() => handleChange('checkStyle')}
              className="rounded border-gray-300 text-red-600 focus:ring-red-500"
            />
            <span>Revisar estil</span>
          </label>
        </div>

        <button
          onClick={onClose}
          className="mt-6 w-full bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors"
        >
          Desar canvis
        </button>
      </div>
    </div>
  );
}