import React, { useState } from 'react';
import { CatalanCorrector } from '../utils/corrector/CatalanCorrector';
import type { Dialect } from '../utils/corrector/types';

export function CorrectorTest() {
  const [inputText, setInputText] = useState('Aquet es un texte en catala central amb bastants errades ortografiques.');
  const [correctedText, setCorrectedText] = useState('');
  const [dialect, setDialect] = useState<Dialect>('central');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleCorrect = async () => {
    if (!inputText.trim()) return;
    
    setIsLoading(true);
    setError(null);
    
    try {
      const corrector = new CatalanCorrector({ dialect });
      const result = await corrector.correct(inputText);
      setCorrectedText(result.corrected);
    } catch (error) {
      console.error('Error correcting text:', error);
      setError('Hi ha hagut un error en corregir el text. Si us plau, torna-ho a provar.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      <div className="bg-white rounded-xl shadow-lg p-8">
        <h2 className="text-2xl font-bold mb-6">Test del Corrector</h2>
        
        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Dialecte:
          </label>
          <select
            value={dialect}
            onChange={(e) => setDialect(e.target.value as Dialect)}
            className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
          >
            <option value="central">Català Central</option>
            <option value="valencia">Valencià</option>
            <option value="balear">Balear</option>
          </select>
        </div>
        
        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Text Original:
          </label>
          <textarea
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            className="w-full h-32 p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent resize-none"
            placeholder="Escriu o enganxa el text aquí..."
          />
        </div>

        {error && (
          <div className="mb-6 p-4 bg-red-50 text-red-700 rounded-lg">
            {error}
          </div>
        )}

        <button
          onClick={handleCorrect}
          disabled={isLoading || !inputText.trim()}
          className="w-full mb-6 bg-red-600 text-white px-6 py-3 rounded-lg hover:bg-red-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
        >
          {isLoading ? (
            <span className="flex items-center">
              <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Corregint...
            </span>
          ) : (
            'Corregir'
          )}
        </button>

        {correctedText && (
          <div>
            <h3 className="text-lg font-semibold mb-2">Text Corregit:</h3>
            <div className="p-4 bg-gray-50 rounded-lg">
              <p>{correctedText}</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}