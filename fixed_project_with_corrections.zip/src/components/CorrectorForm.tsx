import React from 'react';
import { CheckCircle2, Settings, Copy, Eraser } from 'lucide-react';

interface CorrectorFormProps {
  text: string;
  dialect: string;
  onTextChange: (text: string) => void;
  onDialectChange: (dialect: string) => void;
  onCorrect: () => void;
  onCopy: () => void;
  onClear: () => void;
}

export function CorrectorForm({
  text,
  dialect,
  onTextChange,
  onDialectChange,
  onCorrect,
  onCopy,
  onClear
}: CorrectorFormProps) {
  return (
    <div className="bg-white rounded-lg shadow-lg p-6 mb-12">
      <div className="flex items-center space-x-4 mb-4">
        <div className="flex items-center space-x-2">
          <input
            type="radio"
            id="central"
            name="dialect"
            value="central"
            checked={dialect === 'central'}
            onChange={(e) => onDialectChange(e.target.value)}
            className="text-red-600 focus:ring-red-500"
          />
          <label htmlFor="central">Català central</label>
        </div>
        <div className="flex items-center space-x-2">
          <input
            type="radio"
            id="valencia"
            name="dialect"
            value="valencia"
            checked={dialect === 'valencia'}
            onChange={(e) => onDialectChange(e.target.value)}
            className="text-red-600 focus:ring-red-500"
          />
          <label htmlFor="valencia">Valencià</label>
        </div>
        <div className="flex items-center space-x-2">
          <input
            type="radio"
            id="balear"
            name="dialect"
            value="balear"
            checked={dialect === 'balear'}
            onChange={(e) => onDialectChange(e.target.value)}
            className="text-red-600 focus:ring-red-500"
          />
          <label htmlFor="balear">Balear</label>
        </div>
      </div>

      <div className="relative">
        <textarea
          value={text}
          onChange={(e) => onTextChange(e.target.value)}
          className="w-full h-64 p-4 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
          placeholder="Escriu o enganxa el teu text aquí..."
        />
        <div className="absolute bottom-4 right-4 flex space-x-2">
          <button 
            onClick={onCopy}
            className="p-2 text-gray-500 hover:text-red-600" 
            title="Copiar"
          >
            <Copy className="h-5 w-5" />
          </button>
          <button 
            onClick={onClear}
            className="p-2 text-gray-500 hover:text-red-600" 
            title="Esborrar"
          >
            <Eraser className="h-5 w-5" />
          </button>
          <button className="p-2 text-gray-500 hover:text-red-600" title="Configuració">
            <Settings className="h-5 w-5" />
          </button>
        </div>
      </div>

      <button 
        onClick={onCorrect}
        className="mt-4 bg-red-600 text-white px-6 py-2 rounded-lg hover:bg-red-700 flex items-center justify-center space-x-2"
      >
        <CheckCircle2 className="h-5 w-5" />
        <span>Corregir text</span>
      </button>
    </div>
  );
}