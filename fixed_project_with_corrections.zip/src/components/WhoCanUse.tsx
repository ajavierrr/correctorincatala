import React from 'react';
import { GraduationCap, Briefcase, PenTool, Users } from 'lucide-react';

export function WhoCanUse() {
  const users = [
    {
      icon: <GraduationCap className="h-8 w-8 text-red-600" />,
      title: "A l'escola o la universitat",
      description: "Lliura treballs impecables i sense errades"
    },
    {
      icon: <Briefcase className="h-8 w-8 text-red-600" />,
      title: "A la feina",
      description: "Corregeix informes i correus professionals amb qualitat garantida"
    },
    {
      icon: <PenTool className="h-8 w-8 text-red-600" />,
      title: "A les xarxes socials",
      description: "Publica posts i missatges sense errors"
    },
    {
      icon: <Users className="h-8 w-8 text-red-600" />,
      title: "Als correus personals",
      description: "Impressiona amb textos clars i professionals"
    }
  ];

  return (
    <div className="py-8">
      <p className="text-lg text-gray-600 mb-8">
        Aquesta eina és perfecta per a qualsevol situació. Alguns exemples d'on pots utilitzar el 
        nostre corrector català:
      </p>
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
        {users.map((user, index) => (
          <div key={index} className="text-center p-6 bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-red-50 mb-4">
              {user.icon}
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">{user.title}</h3>
            <p className="text-gray-600">{user.description}</p>
          </div>
        ))}
      </div>
    </div>
  );
}