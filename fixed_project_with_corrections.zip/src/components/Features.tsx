import React from 'react';
import { 
  CheckCircle2, 
  Zap, 
  Settings, 
  Clock,
  GraduationCap,
  Briefcase,
  PenTool,
  Users,
  Languages,
  BookOpen,
  Sparkles,
  Globe
} from 'lucide-react';

export function Features() {
  const features = [
    {
      icon: <CheckCircle2 className="h-8 w-8 text-red-600" />,
      title: 'Ortografia Impecable',
      description: 'Corregeix faltes al moment amb total precisió'
    },
    {
      icon: <BookOpen className="h-8 w-8 text-red-600" />,
      title: 'Revisió Gramatical Avançada',
      description: 'Soluciona errors de conjugació, concordança i estructures complexes'
    },
    {
      icon: <Sparkles className="h-8 w-8 text-red-600" />,
      title: 'Millores d\'Estil Intel·ligents',
      description: 'Suggeriments per optimitzar la qualitat i la claredat dels teus textos'
    },
    {
      icon: <Globe className="h-8 w-8 text-red-600" />,
      title: 'Sempre Accessible',
      description: 'Funciona al teu mòbil, ordinador o tauleta sense necessitat de descàrregues'
    },
    {
      icon: <Languages className="h-8 w-8 text-red-600" />,
      title: 'Adaptat als Dialectes Catalans',
      description: 'Central, valencià o balear, amb total compatibilitat lingüística'
    }
  ];

  return (
    <div className="prose prose-red max-w-none">
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {features.map((feature, index) => (
          <div key={index} className="flex items-start space-x-3 bg-white p-6 rounded-xl shadow-sm hover:shadow-md transition-shadow">
            <div className="flex-shrink-0">
              {feature.icon}
            </div>
            <div>
              <h3 className="font-semibold text-gray-900 mb-1">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}