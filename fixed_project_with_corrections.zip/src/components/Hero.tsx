import React from 'react';

export function Hero() {
  return (
    <div className="py-12 bg-gradient-to-br from-red-50 via-white to-red-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-4xl mx-auto">
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-gray-900 tracking-tight mb-6">
            <span className="bg-gradient-to-r from-red-600 to-red-500 bg-clip-text text-transparent">
              Corrector de Català
            </span>
            <span className="block text-2xl sm:text-3xl lg:text-4xl mt-4">
              Ortografia i Gramàtica en Línia
            </span>
          </h1>
          <p className="text-lg text-gray-600 leading-relaxed max-w-3xl mx-auto">
            El nostre <strong>corrector català en línia</strong> és just el que necessites. Una <strong>eina avançada</strong> que 
            revisa la teva <strong>ortografia, gramàtica i estil</strong> de manera instantània i amb total precisió. 
            Tant si ets <strong>estudiant, professional o escriptor</strong>, aquesta eina de correcció catalana 
            s'adapta a totes les teves necessitats, assegurant que els teus textos siguin sempre perfectes.
          </p>
        </div>
      </div>
    </div>
  );
}