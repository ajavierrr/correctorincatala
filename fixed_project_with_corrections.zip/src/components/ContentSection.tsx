import React from 'react';

interface ContentSectionProps {
  id: string;
  title: string;
  children: React.ReactNode;
  className?: string;
}

export function ContentSection({ id, title, children, className = '' }: ContentSectionProps) {
  return (
    <section id={id} className={`content-section scroll-mt-20 ${className}`}>
      <h2 className="section-title">{title}</h2>
      <div className="prose prose-lg">
        {children}
      </div>
    </section>
  );
}