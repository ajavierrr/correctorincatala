import React from 'react';
import { CheckCircle2, Shield, Clock, Sparkles } from 'lucide-react';

export function WhyChooseUs() {
  return (
    <div className="py-8">
      <h2 className="text-3xl font-bold text-gray-900 mb-6">
        Per Què Necessites un Corrector en Català?
      </h2>
      <p className="text-lg text-gray-600 mb-8">
        El català és una llengua plena de matisos i normes gramaticals complexes. És normal tenir dubtes 
        ortogràfics o gramaticals, especialment quan escrius amb pressa o en situacions professionals 
        importants. Un corrector català en línia com el nostre no només detecta errors al moment, sinó 
        que també et garanteix una escriptura sense faltes, clara i professional.
      </p>
      <div className="grid md:grid-cols-2 gap-6">
        <div className="flex items-start space-x-4 p-6 bg-white rounded-xl shadow-sm">
          <CheckCircle2 className="h-6 w-6 text-red-600 flex-shrink-0" />
          <div>
            <h3 className="font-semibold text-gray-900 mb-1">Revisar textos llargs en segons</h3>
            <p className="text-gray-600">Sense esperes, sense complicacions</p>
          </div>
        </div>
        <div className="flex items-start space-x-4 p-6 bg-white rounded-xl shadow-sm">
          <Shield className="h-6 w-6 text-red-600 flex-shrink-0" />
          <div>
            <h3 className="font-semibold text-gray-900 mb-1">Evitar errors comuns</h3>
            <p className="text-gray-600">Gràcies a la revisió ortogràfica i millores d'estil</p>
          </div>
        </div>
        <div className="flex items-start space-x-4 p-6 bg-white rounded-xl shadow-sm">
          <Clock className="h-6 w-6 text-red-600 flex-shrink-0" />
          <div>
            <h3 className="font-semibold text-gray-900 mb-1">Treballar des de qualsevol dispositiu</h3>
            <p className="text-gray-600">Ordinador, mòbil o tauleta. Sempre disponible</p>
          </div>
        </div>
        <div className="flex items-start space-x-4 p-6 bg-white rounded-xl shadow-sm">
          <Sparkles className="h-6 w-6 text-red-600 flex-shrink-0" />
          <div>
            <h3 className="font-semibold text-gray-900 mb-1">Escriptura sense faltes</h3>
            <p className="text-gray-600">Amb el nostre corrector, la teva escriptura en català sempre estarà a l'altura</p>
          </div>
        </div>
      </div>
    </div>
  );
}