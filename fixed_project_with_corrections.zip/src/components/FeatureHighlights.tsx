import React from 'react';
import { 
  CheckCircle2, 
  Clock, 
  Shield, 
  FileText,
  Settings,
  Target,
  GraduationCap,
  Briefcase,
  PenTool,
  Users
} from 'lucide-react';

export function FeatureHighlights() {
  const mainFeatures = [
    {
      icon: <CheckCircle2 className="h-6 w-6 text-red-500" />,
      title: "Corregir errors ortogràfics i gramaticals",
      description: "Detectem i corregim errors de manera instantània"
    },
    {
      icon: <Target className="h-6 w-6 text-red-500" />,
      title: "Verificar la unitat",
      description: "Assegurem que els teus textos siguin clars i correctes"
    },
    {
      icon: <Clock className="h-6 w-6 text-red-500" />,
      title: "Millora instantània",
      description: "Resultats immediats sense esperes"
    },
    {
      icon: <Shield className="h-6 w-6 text-red-500" />,
      title: "Assegurar la correcció lingüística",
      description: "Garantim la qualitat en tot moment"
    }
  ];

  const steps = [
    {
      icon: <FileText className="h-6 w-6 text-red-500" />,
      title: "1. Enganxa el text",
      description: "Copia i enganxa el text que vols corregir al quadre de text principal"
    },
    {
      icon: <Settings className="h-6 w-6 text-red-500" />,
      title: "2. Selecciona el dialecte",
      description: "Tria entre català central, valencià o balear segons les teves necessitats"
    },
    {
      icon: <Target className="h-6 w-6 text-red-500" />,
      title: "3. Revisa i corregeix",
      description: "Fes clic a 'Corregir text' i revisa les suggerències de millora"
    }
  ];

  const userTypes = [
    {
      icon: <GraduationCap className="h-6 w-6 text-red-500" />,
      title: "Estudiants",
      description: "Entrega els teus treballs perfectes i millora les teves notes"
    },
    {
      icon: <Briefcase className="h-6 w-6 text-red-500" />,
      title: "Professionals",
      description: "Els teus correus i informes, impecables sempre"
    },
    {
      icon: <PenTool className="h-6 w-6 text-red-500" />,
      title: "Escriptors i redactors",
      description: "Expressa't amb un català natural i fluid"
    },
    {
      icon: <Users className="h-6 w-6 text-red-500" />,
      title: "Particulars",
      description: "Escriu missatges i posts sense dubtar mai"
    }
  ];

  return (
    <div className="py-12 space-y-16">
      {/* Main Features */}
      <div className="grid md:grid-cols-2 gap-8">
        {mainFeatures.map((feature, index) => (
          <div key={index} className="flex items-start space-x-4">
            <div className="flex-shrink-0">{feature.icon}</div>
            <div>
              <h3 className="font-medium text-gray-900">{feature.title}</h3>
              <p className="text-sm text-gray-500">{feature.description}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Steps */}
      <div className="grid md:grid-cols-3 gap-8">
        {steps.map((step, index) => (
          <div key={index} className="text-center">
            <div className="flex justify-center mb-4">{step.icon}</div>
            <h3 className="font-medium text-gray-900 mb-2">{step.title}</h3>
            <p className="text-sm text-gray-500">{step.description}</p>
          </div>
        ))}
      </div>

      {/* User Types */}
      <div className="grid md:grid-cols-4 gap-8">
        {userTypes.map((type, index) => (
          <div key={index} className="text-center">
            <div className="flex justify-center mb-4">{type.icon}</div>
            <h3 className="font-medium text-gray-900 mb-2">{type.title}</h3>
            <p className="text-sm text-gray-500">{type.description}</p>
          </div>
        ))}
      </div>
    </div>
  );
}