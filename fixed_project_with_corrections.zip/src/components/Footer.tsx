import React from 'react';
import { Link } from 'react-router-dom';
import { Languages, Mail } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-white border-t border-red-100 mt-12">
      <div className="max-w-7xl mx-auto px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-8 mb-8">
          {/* Logo and Description */}
          <div>
            <Link 
              to="/"
              className="flex items-center space-x-2 hover:opacity-80 transition-opacity mb-4"
            >
              <Languages className="h-6 w-6 text-red-600" />
              <span className="text-xl font-bold bg-gradient-to-r from-red-600 to-red-500 bg-clip-text text-transparent">
                Corrector de Català
              </span>
            </Link>
            <p className="text-sm text-gray-600">
              El teu corrector de català en línia. Fàcil, ràpid i gratuït.
            </p>
          </div>

          {/* Corrector Options */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Correctors</h3>
            <nav className="flex flex-col space-y-2 text-sm text-gray-600">
              <Link 
                to="/"
                className="hover:text-red-600 transition-colors"
              >
                Corrector Català
              </Link>
              <Link 
                to="/corrector-valencia"
                className="hover:text-red-600 transition-colors"
              >
                Corrector Valencià
              </Link>
              <Link 
                to="/corrector-balear"
                className="hover:text-red-600 transition-colors"
              >
                Corrector Balear
              </Link>
            </nav>
          </div>

          {/* Contact Information */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Contacte</h3>
            <div className="space-y-2">
              <div className="flex items-center space-x-2 text-gray-600">
                <Mail className="h-5 w-5" />
                <a href="mailto:info@correctorcatala.cat" className="hover:text-red-600 transition-colors">
                  info@correctorcatala.cat
                </a>
              </div>
              <p className="text-sm text-gray-600">
                Horari d'atenció:<br />
                Dilluns a divendres<br />
                9:00 - 18:00
              </p>
              <Link 
                to="/contacte"
                className="inline-block mt-2 text-red-600 hover:text-red-700 transition-colors"
              >
                Formulari de contacte
              </Link>
            </div>
          </div>

          {/* Legal Links */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Legal</h3>
            <nav className="flex flex-col space-y-2 text-sm text-gray-600">
              <Link 
                to="/avis-legal"
                className="hover:text-red-600 transition-colors"
              >
                Avís Legal
              </Link>
              <Link 
                to="/politica-privacitat"
                className="hover:text-red-600 transition-colors"
              >
                Política de Privacitat
              </Link>
              <Link 
                to="/politica-cookies"
                className="hover:text-red-600 transition-colors"
              >
                Política de Cookies
              </Link>
            </nav>
          </div>
        </div>

        <div className="border-t border-gray-200 pt-8">
          <p className="text-center text-gray-500 text-sm">
            © {new Date().getFullYear()} Corrector de Català. Tots els drets reservats.
          </p>
        </div>
      </div>
    </footer>
  );
}