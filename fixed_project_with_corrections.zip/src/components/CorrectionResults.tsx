import React from 'react';
import { AlertCircle } from 'lucide-react';
import type { Correction } from '../utils/corrector';

interface CorrectionResultsProps {
  corrections: Correction[];
}

export function CorrectionResults({ corrections }: CorrectionResultsProps) {
  if (corrections.length === 0) {
    return null;
  }

  return (
    <div className="mt-6 bg-white rounded-lg shadow-lg p-6">
      <h3 className="text-lg font-semibold mb-4">Suggeriments de correcció</h3>
      <div className="space-y-4">
        {corrections.map((correction, index) => (
          <div key={index} className="flex items-start space-x-3 p-3 bg-red-50 rounded-md">
            <AlertCircle className="h-5 w-5 text-red-600 mt-0.5" />
            <div>
              <p className="text-sm font-medium text-gray-900">
                "{correction.original}" → "{correction.suggestion}"
              </p>
              <p className="text-sm text-gray-600">{correction.description}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}