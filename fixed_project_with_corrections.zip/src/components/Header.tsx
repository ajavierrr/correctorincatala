import React, { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Languages, Menu, X } from 'lucide-react';

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  const menuItems = [
    { href: '/', text: 'Corrector Català' },
    { href: '/corrector-valencia', text: 'Corrector Valencià' },
    { href: '/corrector-balear', text: 'Corrector Balear' },
    { href: '/per-que-triar-nos', text: 'Per què triar-nos' },
    { href: '/caracteristiques', text: 'Característiques' },
    { href: '/com-funciona', text: 'Com Funciona' },
    { href: '/qui-pot-usar-lo', text: 'Qui pot usar-lo' },
    { href: '/faq', text: 'FAQ' }
  ];

  const handleNavigation = (href: string) => {
    setIsMenuOpen(false);
    navigate(href);
  };

  return (
    <header className="bg-white/80 backdrop-blur-sm sticky top-0 z-50 border-b border-red-100">
      <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center">
          <Link 
            to="/"
            className="flex items-center space-x-2 hover:opacity-80 transition-opacity"
          >
            <Languages className="h-8 w-8 text-red-600" />
            <span className="text-2xl font-bold bg-gradient-to-r from-red-600 to-red-500 bg-clip-text text-transparent">
              Corrector de Català
            </span>
          </Link>

          {/* Desktop Menu */}
          <nav className="hidden md:flex items-center space-x-6">
            {menuItems.map((item) => (
              <button
                key={item.href}
                onClick={() => handleNavigation(item.href)}
                className={`text-gray-600 hover:text-red-600 transition-colors ${
                  location.pathname === item.href ? 'text-red-600 font-medium' : ''
                }`}
              >
                {item.text}
              </button>
            ))}
          </nav>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden p-2 text-gray-600 hover:text-red-600"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            aria-label={isMenuOpen ? 'Tancar menú' : 'Obrir menú'}
          >
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <nav className="md:hidden mt-4 space-y-2">
            {menuItems.map((item) => (
              <button
                key={item.href}
                onClick={() => handleNavigation(item.href)}
                className={`block w-full text-left py-2 text-gray-600 hover:text-red-600 transition-colors ${
                  location.pathname === item.href ? 'text-red-600 font-medium' : ''
                }`}
              >
                {item.text}
              </button>
            ))}
          </nav>
        )}
      </div>
    </header>
  );
}