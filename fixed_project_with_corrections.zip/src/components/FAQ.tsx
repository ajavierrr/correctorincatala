import React from 'react';
import { 
  Plus, 
  Minus, 
  CreditCard, 
  Smartphone, 
  CheckCircle2, 
  Globe2, 
  UserPlus,
  HelpCircle 
} from 'lucide-react';

export function FAQ() {
  const [openIndex, setOpenIndex] = React.useState<number | null>(null);

  const questions = [
    {
      icon: <CreditCard className="h-6 w-6 text-red-600" />,
      question: 'És gratuït?',
      answer: 'Sí, la versió bàsica del nostre corrector és totalment gratuïta i accessible per a tothom.'
    },
    {
      icon: <Smartphone className="h-6 w-6 text-red-600" />,
      question: 'Funciona en tots els dispositius?',
      answer: 'Per descomptat! Pots utilitzar-lo al mòbil, ordinador o tauleta sense cap problema.'
    },
    {
      icon: <CheckCircle2 className="h-6 w-6 text-red-600" />,
      question: 'Quin tipus d\'errors detecta?',
      answer: 'El nostre corrector revisa errors ortogràfics, gramaticals i estilístics, a més de suggerir millores d\'estil.'
    },
    {
      icon: <Globe2 className="h-6 w-6 text-red-600" />,
      question: 'És compatible amb altres idiomes?',
      answer: 'Actualment, està dissenyat exclusivament per al català, amb adaptació a dialectes com central, valencià i balear.'
    },
    {
      icon: <UserPlus className="h-6 w-6 text-red-600" />,
      question: 'Necessito registrar-me?',
      answer: 'No, pots començar a utilitzar-lo immediatament sense necessitat de registre.'
    },
    {
      icon: <HelpCircle className="h-6 w-6 text-red-600" />,
      question: 'Com puc contactar amb el suport?',
      answer: 'Pots contactar-nos a través del formulari de contacte o enviant un correu a info@correctorcatala.cat.'
    }
  ];

  return (
    <div className="space-y-4">
      {questions.map((item, index) => (
        <div key={index} className="border border-gray-200 rounded-xl overflow-hidden">
          <button
            onClick={() => setOpenIndex(openIndex === index ? null : index)}
            className="w-full px-6 py-4 flex items-center justify-between text-left hover:bg-gray-50 transition-colors"
          >
            <div className="flex items-center space-x-4">
              {item.icon}
              <span className="font-medium text-gray-900">{item.question}</span>
            </div>
            {openIndex === index ? (
              <Minus className="h-5 w-5 text-red-600" />
            ) : (
              <Plus className="h-5 w-5 text-gray-400" />
            )}
          </button>
          {openIndex === index && (
            <div className="px-6 py-4 bg-gray-50 border-t border-gray-200">
              <p className="text-gray-600">{item.answer}</p>
            </div>
          )}
        </div>
      ))}
    </div>
  );
}