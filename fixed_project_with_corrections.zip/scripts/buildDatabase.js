import { dbManager } from './db/database.js';
import { join } from 'path';
import { writeFileSync } from 'fs';

async function buildDatabase() {
  try {
    console.log('Building final database...');

    // Generate TypeScript types for each dialect
    const dialects = ['central', 'valencia', 'balear'];
    
    for (const dialect of dialects) {
      const words = dbManager.db.prepare('SELECT * FROM words WHERE dialect = ?').all(dialect);
      const rules = dbManager.db.prepare('SELECT * FROM grammar_rules WHERE dialect = ?').all(dialect);
      const conjugations = dbManager.db.prepare('SELECT * FROM verb_conjugations WHERE dialect = ?').all(dialect);

      const dialectData = {
        words,
        rules,
        conjugations
      };

      writeFileSync(
        join('src', 'utils', 'dialectData', `${dialect}Rules.ts`),
        `export const ${dialect}Rules = ${JSON.stringify(dialectData, null, 2)};`
      );
    }

    console.log('Database build completed successfully!');
  } catch (error) {
    console.error('Error building database:', error);
  } finally {
    dbManager.close();
  }
}

buildDatabase().catch(console.error);