CREATE TABLE IF NOT EXISTS words (
  id INTEGER PRIMARY KEY,
  word TEXT NOT NULL,
  dialect TEXT NOT NULL,
  definition TEXT,
  category TEXT,
  source TEXT,
  notes TEXT,
  UNIQUE(word, dialect)
);

CREATE TABLE IF NOT EXISTS grammar_rules (
  id INTEGER PRIMARY KEY,
  rule TEXT NOT NULL,
  pattern TEXT NOT NULL,
  replacement TEXT,
  dialect TEXT NOT NULL,
  category TEXT,
  description TEXT,
  examples TEXT,
  source TEXT,
  UNIQUE(pattern, dialect)
);

CREATE TABLE IF NOT EXISTS verb_conjugations (
  id INTEGER PRIMARY KEY,
  verb TEXT NOT NULL,
  infinitive TEXT NOT NULL,
  tense TEXT NOT NULL,
  person TEXT NOT NULL,
  number TEXT NOT NULL,
  conjugation TEXT NOT NULL,
  dialect TEXT NOT NULL,
  source TEXT,
  UNIQUE(verb, tense, person, number, dialect)
);

CREATE TABLE IF NOT EXISTS expressions (
  id INTEGER PRIMARY KEY,
  expression TEXT NOT NULL,
  meaning TEXT,
  dialect TEXT NOT NULL,
  category TEXT,
  source TEXT,
  UNIQUE(expression, dialect)
);

CREATE TABLE IF NOT EXISTS variants (
  id INTEGER PRIMARY KEY,
  word_id INTEGER,
  variant TEXT NOT NULL,
  dialect TEXT NOT NULL,
  source TEXT,
  FOREIGN KEY(word_id) REFERENCES words(id),
  UNIQUE(variant, dialect)
);