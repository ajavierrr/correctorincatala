import Database from 'better-sqlite3';
import { readFileSync } from 'fs';
import { join } from 'path';

export class DatabaseManager {
  constructor() {
    this.db = new Database('src/data/dictionaries.db');
    this.initializeDatabase();
  }

  initializeDatabase() {
    const schema = readFileSync(join('scripts', 'db', 'schema.sql'), 'utf-8');
    this.db.exec(schema);
  }

  insertWord(word, dialect, definition = null, category = null, source = null, notes = null) {
    const stmt = this.db.prepare(`
      INSERT OR REPLACE INTO words (word, dialect, definition, category, source, notes)
      VALUES (?, ?, ?, ?, ?, ?)
    `);
    return stmt.run(word, dialect, definition, category, source, notes);
  }

  insertGrammarRule(rule, pattern, replacement, dialect, category = null, description = null, examples = null, source = null) {
    const stmt = this.db.prepare(`
      INSERT OR REPLACE INTO grammar_rules 
      (rule, pattern, replacement, dialect, category, description, examples, source)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `);
    return stmt.run(rule, pattern, replacement, dialect, category, description, examples, source);
  }

  insertVerbConjugation(verb, infinitive, tense, person, number, conjugation, dialect, source = null) {
    const stmt = this.db.prepare(`
      INSERT OR REPLACE INTO verb_conjugations 
      (verb, infinitive, tense, person, number, conjugation, dialect, source)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `);
    return stmt.run(verb, infinitive, tense, person, number, conjugation, dialect, source);
  }

  close() {
    this.db.close();
  }
}

export const dbManager = new DatabaseManager();