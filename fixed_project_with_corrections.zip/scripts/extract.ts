import { extractAllData } from '../src/utils/extraction/extractor';

extractAllData()
  .then(() => console.log('Extraction process completed'))
  .catch(error => {
    console.error('Error during extraction:', error);
    process.exit(1);
  });