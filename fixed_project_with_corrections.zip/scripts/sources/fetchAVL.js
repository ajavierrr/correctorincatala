import puppeteer from 'puppeteer';
import { dbManager } from '../db/database.js';
import { SOURCES } from '../config/sources.js';

async function fetchAVL() {
  const browser = await puppeteer.launch({ headless: "new" });
  const page = await browser.newPage();
  
  try {
    console.log('Fetching AVL dictionary data...');
    await page.goto(SOURCES.AVL.url);

    // Implementar la lógica de extracción específica para AVL
    // Ejemplo: extraer palabras valencianas y variantes

    const words = await page.evaluate(() => {
      // Lógica de extracción
      return [];
    });

    // Guardar en la base de datos
    for (const word of words) {
      dbManager.insertWord(
        word.term,
        'valencia',
        word.definition,
        word.category,
        'AVL'
      );
    }

  } catch (error) {
    console.error('Error fetching AVL data:', error);
  } finally {
    await browser.close();
  }
}

fetchAVL().catch(console.error);