export const SOURCES = {
  IEC: {
    name: 'Institut d\'Estudis Catalans',
    url: 'https://dlc.iec.cat/Results',
    type: 'dictionary',
    dialect: 'central'
  },
  AVL: {
    name: 'Acadèmia Valenciana de la Llengua',
    url: 'https://www.avl.gva.es/lexicval',
    type: 'dictionary',
    dialect: 'valencia'
  },
  UIB: {
    name: 'Universitat de les Illes Balears',
    url: 'https://www.uib.cat/diccionari',
    type: 'dictionary',
    dialect: 'balear'
  },
  TERMCAT: {
    name: 'TERMCAT',
    url: 'https://www.termcat.cat/ca/diccionaris-en-linia',
    type: 'terminology'
  },
  OPTIMOT: {
    name: 'Optimot',
    url: 'https://aplicacions.llengua.gencat.cat/llc/AppJava/index.html',
    type: 'grammar'
  },
  SOFTCATALA: {
    name: 'Softcatalà',
    url: 'https://www.softcatala.org/recursos',
    type: 'technology'
  },
  DCVB: {
    name: 'Diccionari català-valencià-balear',
    url: 'https://dcvb.iec.cat',
    type: 'comprehensive'
  }
};