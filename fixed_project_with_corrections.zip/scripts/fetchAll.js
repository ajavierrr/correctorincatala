import { execSync } from 'child_process';

async function fetchAllData() {
  const sources = [
    'iec',
    'avl',
    'uib',
    'termcat',
    'optimot',
    'softcatala',
    'dcvb'
  ];

  console.log('Starting data extraction from all sources...');

  for (const source of sources) {
    try {
      console.log(`\nFetching data from ${source.toUpperCase()}...`);
      execSync(`npm run fetch:${source}`, { stdio: 'inherit' });
    } catch (error) {
      console.error(`Error fetching data from ${source}:`, error);
    }
  }

  console.log('\nBuilding final database...');
  execSync('npm run build:db', { stdio: 'inherit' });

  console.log('\nData extraction completed!');
}

fetchAllData().catch(console.error);