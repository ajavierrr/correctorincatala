import Database from 'better-sqlite3';
import { readFileSync } from 'fs';
import { join } from 'path';

async function initializeDB() {
  const db = new Database('src/data/dictionaries.db');

  // Create tables
  db.exec(`
    CREATE TABLE IF NOT EXISTS dictionary (
      id INTEGER PRIMARY KEY,
      word TEXT NOT NULL,
      dialect TEXT NOT NULL,
      category TEXT,
      correct_form TEXT,
      description TEXT
    );

    CREATE TABLE IF NOT EXISTS grammar_rules (
      id INTEGER PRIMARY KEY,
      pattern TEXT NOT NULL,
      replacement TEXT NOT NULL,
      dialect TEXT NOT NULL,
      description TEXT,
      category TEXT
    );

    CREATE TABLE IF NOT EXISTS verb_conjugations (
      id INTEGER PRIMARY KEY,
      infinitive TEXT NOT NULL,
      conjugation TEXT NOT NULL,
      tense TEXT NOT NULL,
      person TEXT NOT NULL,
      dialect TEXT NOT NULL
    );
  `);

  // Load initial data
  const dialectData = {
    central: JSON.parse(readFileSync(join('src', 'data', 'central.json'), 'utf-8')),
    valencia: JSON.parse(readFileSync(join('src', 'data', 'valencia.json'), 'utf-8')),
    balear: JSON.parse(readFileSync(join('src', 'data', 'balear.json'), 'utf-8'))
  };

  // Insert data for each dialect
  for (const [dialect, data] of Object.entries(dialectData)) {
    const insertWord = db.prepare(
      'INSERT INTO dictionary (word, dialect, category, correct_form, description) VALUES (?, ?, ?, ?, ?)'
    );
    const insertRule = db.prepare(
      'INSERT INTO grammar_rules (pattern, replacement, dialect, description, category) VALUES (?, ?, ?, ?, ?)'
    );
    const insertConjugation = db.prepare(
      'INSERT INTO verb_conjugations (infinitive, conjugation, tense, person, dialect) VALUES (?, ?, ?, ?, ?)'
    );

    db.transaction(() => {
      // Insert dictionary words
      data.dictionary.forEach(entry => {
        insertWord.run(entry.word, dialect, entry.category, entry.correctForm, entry.description);
      });

      // Insert grammar rules
      data.grammar.forEach(rule => {
        insertRule.run(rule.pattern, rule.replacement, dialect, rule.description, rule.category);
      });

      // Insert verb conjugations
      data.conjugations.forEach(conj => {
        insertConjugation.run(conj.infinitive, conj.conjugation, conj.tense, conj.person, dialect);
      });
    })();
  }

  db.close();
}

initializeDB().catch(console.error);