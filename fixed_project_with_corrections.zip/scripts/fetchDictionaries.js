import fetch from 'node-fetch';
import Database from 'better-sqlite3';
import { writeFileSync } from 'fs';
import { join } from 'path';

const SOURCES = {
  IEC: 'https://dlc.iec.cat/Results',
  AVL: 'https://www.avl.gva.es/lexicval',
  TERMCAT: 'https://www.termcat.cat/ca/diccionaris-en-linia',
  OPTIMOT: 'https://aplicacions.llengua.gencat.cat/llc/AppJava/index.html'
};

async function fetchDictionaries() {
  const db = new Database('src/data/dictionaries.db');

  // Create tables
  db.exec(`
    CREATE TABLE IF NOT EXISTS words (
      id INTEGER PRIMARY KEY,
      word TEXT NOT NULL,
      dialect TEXT NOT NULL,
      definition TEXT,
      category TEXT,
      notes TEXT
    );

    CREATE TABLE IF NOT EXISTS grammar_rules (
      id INTEGER PRIMARY KEY,
      rule TEXT NOT NULL,
      dialect TEXT NOT NULL,
      description TEXT,
      examples TEXT
    );

    CREATE TABLE IF NOT EXISTS verb_conjugations (
      id INTEGER PRIMARY KEY,
      verb TEXT NOT NULL,
      tense TEXT NOT NULL,
      person TEXT NOT NULL,
      conjugation TEXT NOT NULL,
      dialect TEXT NOT NULL
    );
  `);

  // Fetch data from each source
  for (const [source, url] of Object.entries(SOURCES)) {
    try {
      console.log(`Fetching data from ${source}...`);
      // Aquí implementaríamos la lógica específica para cada fuente
      // Ya que cada sitio tiene su propia estructura y API
    } catch (error) {
      console.error(`Error fetching from ${source}:`, error);
    }
  }

  // Export rules to TypeScript files
  generateTypeScriptRules(db);

  db.close();
}

function generateTypeScriptRules(db) {
  // Generate rules for each dialect
  const dialects = ['central', 'valencia', 'balear'];
  
  for (const dialect of dialects) {
    const rules = {
      spelling: db.prepare('SELECT * FROM words WHERE dialect = ?').all(dialect),
      grammar: db.prepare('SELECT * FROM grammar_rules WHERE dialect = ?').all(dialect),
      conjugations: db.prepare('SELECT * FROM verb_conjugations WHERE dialect = ?').all(dialect)
    };

    writeFileSync(
      join('src', 'utils', 'dialectData', `${dialect}Rules.ts`),
      `export const ${dialect}Rules = ${JSON.stringify(rules, null, 2)};`
    );
  }
}

fetchDictionaries().catch(console.error);