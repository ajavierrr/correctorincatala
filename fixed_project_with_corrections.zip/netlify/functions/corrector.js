
const { Configuration, OpenAIApi } = require('openai');

const configuration = new Configuration({
  apiKey: process.env.OPENAI_API_KEY, // Configura esta clave en Netlify
});
const openai = new OpenAIApi(configuration);

exports.handler = async function (event) {
  try {
    const { text, dialect } = JSON.parse(event.body);
    const prompt = `
      Corrige el siguiente texto en ${dialect === 'central' ? 'catalán estándar' : dialect}:
      Texto: "${text}"
      Corrige errores ortográficos y gramaticales. Devuelve solo el texto corregido.
    `;

    const response = await openai.createCompletion({
      model: 'text-davinci-003',
      prompt,
      max_tokens: 500,
      temperature: 0.2,
    });

    return {
      statusCode: 200,
      body: JSON.stringify({ correctedText: response.data.choices[0].text.trim() }),
    };
  } catch (error) {
    console.error('Error al conectar con OpenAI:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Error al procesar el texto.' }),
    };
  }
};
